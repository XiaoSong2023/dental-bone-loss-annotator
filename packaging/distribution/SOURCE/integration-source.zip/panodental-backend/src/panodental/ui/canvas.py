from PIL.ImageQt import ImageQt
from PySide6.QtCore import QPointF, Qt, Signal
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen, QPixmap, QPolygonF
from PySide6.QtWidgets import QGraphicsItem, QGraphicsPathItem, QGraphicsPolygonItem, QGraphicsScene, QGraphicsView

COLORS = {"cej": "#efb845", "bone_level": "#45bced", "apex": "#ed7aaf"}


class Handle(QGraphicsPathItem):
    def __init__(self, xy, kind, moved, enabled):
        super().__init__()
        path = QPainterPath()
        if kind == "bone_level":
            path.addRect(-5, -5, 10, 10)
        elif kind == "apex":
            path.addPolygon(QPolygonF([QPointF(0, -6), QPointF(6, 5), QPointF(-6, 5), QPointF(0, -6)]))
        else:
            path.addEllipse(-5, -5, 10, 10)
        self.setPath(path)
        self.setBrush(QColor(COLORS.get(kind, "#ffffff")))
        self.setPen(QPen(QColor("#242a34"), 1))
        self.setPos(*xy)
        self.setZValue(3)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable, enabled)
        self.moved = moved
        self._start = self.pos()

    def mousePressEvent(self, event):
        self._start = self.pos()
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        if self.pos() != self._start:
            self.moved((self.pos().x(), self.pos().y()))


class ToothShape(QGraphicsPolygonItem):
    def __init__(self, points, selected, clicked):
        super().__init__(QPolygonF([QPointF(*p) for p in points]))
        self.clicked = clicked
        pen = QPen(QColor("#ffffff" if selected else "#55cea1"), 2)
        pen.setCosmetic(True)
        self.setPen(pen)
        self.setBrush(QColor(70, 200, 155, 24 if selected else 8))
        self.setZValue(1)

    def mousePressEvent(self, event):
        self.clicked()
        event.accept()


class Canvas(QGraphicsView):
    tooth_selected = Signal(str)
    point_selected = Signal(str)
    point_added = Signal(str, object)
    point_moved = Signal(str, object)
    tooth_drawn = Signal(object)
    contour_moved = Signal(str, int, object)

    def __init__(self):
        super().__init__()
        self.setScene(QGraphicsScene(self))
        self.setBackgroundBrush(QColor("#151b23"))
        self.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.document = None
        self.selected_tooth = None
        self.mode = "browse"
        self.show_annotations = True
        self._draw_points = []
        self._draft = None
        self.set_mode("browse")

    def set_mode(self, mode):
        self.mode = mode
        self._draw_points.clear()
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag if mode == "browse" else QGraphicsView.DragMode.NoDrag)
        self.render()

    def render(self):
        self.scene().clear()
        self._draft = None
        if self.document is None:
            return
        self.scene().addPixmap(QPixmap.fromImage(ImageQt(self.document.image.rgb8())))
        self.setSceneRect(0, 0, *self.document.image.pixels.size)
        if not self.show_annotations:
            return
        for tooth in self.document.annotation.teeth:
            for contour in tooth.contours:
                shape = ToothShape(contour, tooth.instance_id == self.selected_tooth,
                                   lambda tid=tooth.instance_id: self.tooth_selected.emit(tid))
                self.scene().addItem(shape)
            if tooth.instance_id == self.selected_tooth and self.mode == "contour":
                for index, xy in enumerate(tooth.contours[0]):
                    handle = Handle(xy, "vertex", lambda pos, tid=tooth.instance_id, i=index: self.contour_moved.emit(tid, i, pos), True)
                    self.scene().addItem(handle)
        for point in self.document.annotation.landmarks:
            if point.current_xy is None or point.review_status == "rejected":
                continue
            handle = Handle(point.current_xy, point.kind,
                            lambda pos, pid=point.landmark_id: self.point_moved.emit(pid, pos), self.mode == "edit")
            handle.setToolTip(f"{point.kind} · {point.origin} · {point.review_status}")
            self.scene().addItem(handle)

    def fit(self):
        if self.document:
            self.fitInView(self.sceneRect(), Qt.AspectRatioMode.KeepAspectRatio)

    def wheelEvent(self, event):
        factor = 1.2 if event.angleDelta().y() > 0 else 1/1.2
        if .02 < self.transform().m11() * factor < 50:
            self.scale(factor, factor)
        event.accept()

    def mousePressEvent(self, event):
        if self.document and event.button() == Qt.MouseButton.LeftButton:
            pos = self.mapToScene(event.position().toPoint())
            if self.sceneRect().contains(pos):
                if self.mode.startswith("add_"):
                    self.point_added.emit(self.mode[4:], (pos.x(), pos.y()))
                    event.accept()
                    return
                if self.mode == "draw":
                    self._draw_points.append((pos.x(), pos.y()))
                    self._draw_preview()
                    event.accept()
                    return
        super().mousePressEvent(event)

    def _draw_preview(self):
        if self._draft:
            self.scene().removeItem(self._draft)
        polygon = QPolygonF([QPointF(*p) for p in self._draw_points])
        pen = QPen(QColor("#f7d47e"), 2)
        pen.setCosmetic(True)
        self._draft = self.scene().addPolygon(polygon, pen)
        self._draft.setZValue(5)

    def keyPressEvent(self, event):
        if self.mode == "draw" and event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            if len(self._draw_points) >= 3:
                points = self._draw_points.copy()
                self._draw_points.clear()
                self.tooth_drawn.emit(points)
            return
        if event.key() == Qt.Key.Key_Escape:
            self._draw_points.clear()
            self.render()
            return
        super().keyPressEvent(event)
