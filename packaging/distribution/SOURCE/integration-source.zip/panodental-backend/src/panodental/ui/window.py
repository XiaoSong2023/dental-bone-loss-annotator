import json
from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QAction, QKeySequence
from PySide6.QtWidgets import (QApplication, QComboBox, QFileDialog, QFormLayout, QHBoxLayout, QLabel,
                              QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QMessageBox,
                              QPushButton, QSplitter, QToolBar, QVBoxLayout, QWidget)

from ..crops import export_crops
from ..project import Document, atomic_json
from .canvas import Canvas
from .worker_client import WorkerClient

KIND_NAMES = {"cej": "CEJ", "bone_level": "骨水平", "apex": "根尖"}
SIDE_NAMES = [("未知", "unknown"), ("图像左", "image_left"), ("图像右", "image_right"),
              ("近中（需确认）", "mesial"), ("远中（需确认）", "distal"), ("中央", "central")]


class MainWindow(QMainWindow):
    def __init__(self, start_worker=True):
        super().__init__()
        self.setWindowTitle("PanoDental · 全景片标注工作台")
        self.resize(1440, 900)
        self.documents = []
        self.document = None
        self.selected_tooth = None
        self._health = None
        self._probe_report = None
        self.canvas = Canvas()
        self.images = QListWidget()
        self.images.setMinimumWidth(190)
        self.images.currentRowChanged.connect(self._select_image)
        self.teeth = QListWidget()
        self.teeth.currentItemChanged.connect(self._select_tooth)
        self.points = QListWidget()
        self.fdi = QLineEdit()
        self.fdi.setPlaceholderText("牙位未知")
        self.side = QComboBox()
        for label, value in SIDE_NAMES:
            self.side.addItem(label, value)
        self.root_id = QLineEdit()
        self.root_id.setPlaceholderText("可留空")
        self.selection_label = QLabel("请选择或补画一颗牙齿")
        self.selection_label.setWordWrap(True)

        details = QWidget()
        layout = QVBoxLayout(details)
        layout.addWidget(QLabel("牙齿与复核"))
        layout.addWidget(self.teeth, 2)
        layout.addWidget(self.selection_label)
        form = QFormLayout()
        form.addRow("FDI 牙位", self.fdi)
        form.addRow("新增点侧别", self.side)
        form.addRow("新增点根编号", self.root_id)
        layout.addLayout(form)
        row = QHBoxLayout()
        for label, handler in (("保存牙位", self._set_fdi), ("确认当前牙", self._accept), ("删除牙齿", self._delete_tooth)):
            button = QPushButton(label)
            button.clicked.connect(handler)
            row.addWidget(button)
        layout.addLayout(row)
        layout.addWidget(QLabel("点位 · 来源 / 复核状态"))
        layout.addWidget(self.points, 2)
        for label, handler in (("设为不可判读", lambda: self._point_action("not_visible")),
                               ("删除所选点", lambda: self._point_action("delete")),
                               ("恢复模型原始点", lambda: self._point_action("restore"))):
            button = QPushButton(label)
            button.clicked.connect(handler)
            layout.addWidget(button)
        details.setMinimumWidth(330)

        split = QSplitter()
        split.addWidget(self.images)
        split.addWidget(self.canvas)
        split.addWidget(details)
        split.setStretchFactor(1, 1)
        split.setSizes([210, 880, 350])
        container = QWidget()
        main = QVBoxLayout(container)
        self.model_notice = QLabel("自动分割与候选标点：模型尚未配置  ·  可先进行人工标注、复核和导出")
        self.model_notice.setStyleSheet("background:#fff4db; color:#694a13; padding:10px; border-radius:4px;")
        main.addWidget(self.model_notice)
        main.addWidget(split, 1)
        self.setCentralWidget(container)

        toolbar = QToolBar("文件与工具")
        self.addToolBar(toolbar)
        self._action(toolbar, "导入影像", self._import_dialog, QKeySequence.StandardKey.Open)
        self._action(toolbar, "打开项目", self._open_dialog)
        self._action(toolbar, "保存项目", self._save, QKeySequence.StandardKey.Save)
        self._action(toolbar, "导出标注", self._export)
        self._action(toolbar, "导出单牙图", self._crop)
        toolbar.addSeparator()
        self.run_action = self._action(toolbar, "自动运行", self._run)
        self.run_action.setEnabled(False)
        self.run_action.setToolTip("需要真实牙科分割及三类关键点训练权重")
        self._action(toolbar, "模型状态", self._models)
        self._action(toolbar, "适应窗口", self.canvas.fit)
        self._action(toolbar, "原图 / 标注", self._toggle_overlay)
        self._action(toolbar, "撤销", lambda: self._edit(lambda: self.document.undo()), QKeySequence.StandardKey.Undo)
        self._action(toolbar, "重做", lambda: self._edit(lambda: self.document.redo()), QKeySequence.StandardKey.Redo)

        modes = QToolBar("标注模式")
        self.addToolBar(Qt.ToolBarArea.BottomToolBarArea, modes)
        self.mode = QComboBox()
        for label, value in [("浏览 / 平移", "browse"), ("补画牙轮廓（Enter 完成）", "draw"),
                             ("编辑轮廓顶点", "contour"), ("拖动点位", "edit"),
                             ("新增 CEJ 点", "add_cej"), ("新增骨水平点", "add_bone_level"), ("新增根尖点", "add_apex")]:
            self.mode.addItem(label, value)
        self.mode.currentIndexChanged.connect(lambda _: self.canvas.set_mode(self.mode.currentData()))
        modes.addWidget(QLabel("  操作模式  "))
        modes.addWidget(self.mode)
        modes.addWidget(QLabel("   滚轮缩放 · 拖动浏览 · Esc 取消轮廓 · 坐标随原图保存"))

        self.canvas.tooth_selected.connect(self.select_tooth)
        self.canvas.tooth_drawn.connect(self._draw_tooth)
        self.canvas.point_added.connect(self._add_point)
        self.canvas.point_moved.connect(lambda pid, xy: self._edit(lambda: self.document.move_point(pid, xy)))
        self.canvas.contour_moved.connect(self._move_vertex)
        self.worker = WorkerClient(self)
        self.worker.response.connect(self._worker_response)
        self.worker.failure.connect(lambda text: self.statusBar().showMessage(text))
        self.statusBar().showMessage("正在检查 CPU 运行环境…" if start_worker else "人工标注模式")
        if start_worker:
            self.worker.start()

    def _action(self, toolbar, label, callback, shortcut=None):
        action = QAction(label, self)
        action.triggered.connect(lambda _=False: callback())
        if shortcut:
            action.setShortcut(QKeySequence(shortcut))
        toolbar.addAction(action)
        return action

    def add_image(self, path):
        document = Document.from_image(path)
        self._append_document(document)
        return document

    def _append_document(self, document):
        self.documents.append(document)
        self.images.addItem(document.annotation.image.source_name)
        self.images.setCurrentRow(len(self.documents)-1)

    def _import_dialog(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "导入全景片", "", "影像 (*.png *.jpg *.jpeg *.bmp *.tif *.tiff)")
        errors = []
        for path in paths:
            try:
                self.add_image(path)
            except Exception as error:
                errors.append(f"{Path(path).name}: {error}")
        if errors:
            QMessageBox.warning(self, "部分影像未导入", "\n".join(errors))

    def _open_dialog(self):
        path = QFileDialog.getExistingDirectory(self, "选择 .panoproj 项目目录")
        if path:
            self._guard(lambda: self._append_document(Document.open(path)))

    def _select_image(self, row):
        self.document = self.documents[row] if 0 <= row < len(self.documents) else None
        self.selected_tooth = None
        self.canvas.document = self.document
        self.refresh()
        self.canvas.fit()

    def select_tooth(self, instance_id):
        self.selected_tooth = instance_id
        QTimer.singleShot(0, self.refresh)

    def _select_tooth(self, item, previous):
        if item:
            self.selected_tooth = item.data(Qt.ItemDataRole.UserRole)
            self.canvas.selected_tooth = self.selected_tooth
            self.canvas.render()
            self._refresh_points()

    def refresh(self):
        self.teeth.blockSignals(True)
        self.teeth.clear()
        if self.document:
            for tooth in self.document.annotation.teeth:
                item = QListWidgetItem(f"牙位 {tooth.fdi or '未知'}  ·  {tooth.review_status}")
                item.setData(Qt.ItemDataRole.UserRole, tooth.instance_id)
                self.teeth.addItem(item)
                if tooth.instance_id == self.selected_tooth:
                    self.teeth.setCurrentItem(item)
            index = self.documents.index(self.document)
            self.images.item(index).setText(self.document.annotation.image.source_name+(" *" if self.document.dirty else ""))
        self.teeth.blockSignals(False)
        self.canvas.selected_tooth = self.selected_tooth
        self.canvas.render()
        self._refresh_points()

    def _refresh_points(self):
        self.points.clear()
        tooth = next((t for t in self.document.annotation.teeth if t.instance_id == self.selected_tooth), None) if self.document else None
        self.fdi.setText(str(tooth.fdi) if tooth and tooth.fdi else "")
        self.selection_label.setText(f"实例 {tooth.instance_id[:10]} · 来源 {tooth.origin}" if tooth else "请选择或补画一颗牙齿")
        if not tooth:
            return
        for point in self.document.annotation.landmarks:
            if point.instance_id == self.selected_tooth:
                coord = f"({point.current_xy[0]:.1f}, {point.current_xy[1]:.1f})" if point.current_xy else point.location_status
                item = QListWidgetItem(f"{KIND_NAMES[point.kind]} {coord}\n{point.origin} · {point.review_status} · {point.side}")
                item.setData(Qt.ItemDataRole.UserRole, point.landmark_id)
                self.points.addItem(item)

    def _guard(self, call):
        try:
            return call()
        except Exception as error:
            QMessageBox.warning(self, "操作未完成", str(error))
            return None

    def _edit(self, call):
        if self.document:
            self._guard(call)
            QTimer.singleShot(0, self.refresh)

    def _draw_tooth(self, points):
        def draw():
            self.selected_tooth = self.document.add_tooth(points)
        self._edit(draw)

    def _add_point(self, kind, xy):
        if not self.selected_tooth:
            self.statusBar().showMessage("请先选择或补画一颗牙齿")
            return
        self._edit(lambda: self.document.add_point(self.selected_tooth, kind, xy, self.side.currentData(), self.root_id.text().strip() or None))

    def _move_vertex(self, instance_id, index, xy):
        def move():
            tooth = next(t for t in self.document.annotation.teeth if t.instance_id == instance_id)
            points = list(tooth.contours[0])
            points[index] = xy
            self.document.edit_contour(instance_id, points)
        self._edit(move)

    def _set_fdi(self):
        if self.selected_tooth:
            self._edit(lambda: self.document.set_fdi(self.selected_tooth, int(self.fdi.text()) if self.fdi.text().strip() else None))

    def _accept(self):
        if self.selected_tooth:
            self._edit(lambda: self.document.accept_tooth(self.selected_tooth))

    def _delete_tooth(self):
        if self.selected_tooth:
            self._edit(lambda: self.document.delete_tooth(self.selected_tooth))

    def _point_action(self, action):
        item = self.points.currentItem()
        if not item:
            return
        pid = item.data(Qt.ItemDataRole.UserRole)
        if action == "delete":
            self._edit(lambda: self.document.delete_point(pid))
        elif action == "restore":
            self._edit(lambda: self.document.restore_point(pid))
        else:
            self._edit(lambda: self.document.set_point_status(pid, action))

    def _save(self):
        if not self.document:
            return False
        target = self.document.root
        if target is None:
            path, _ = QFileDialog.getSaveFileName(self, "创建项目目录", Path(self.document.annotation.image.source_name).stem+".panoproj", "项目目录 (*.panoproj)")
            if not path:
                return False
            target = Path(path if path.endswith(".panoproj") else path+".panoproj")
        saved = self._guard(lambda: self.document.save(target))
        self.refresh()
        if saved:
            self.statusBar().showMessage("项目已保存")
        return bool(saved)

    def _export(self):
        if self.document:
            folder = QFileDialog.getExistingDirectory(self, "选择导出位置")
            if folder:
                out = self._guard(lambda: self.document.export(folder))
                if out:
                    QMessageBox.information(self, "已导出", str(out))

    def _crop(self):
        if self.document:
            folder = QFileDialog.getExistingDirectory(self, "选择单牙图导出位置")
            if folder:
                out = self._guard(lambda: export_crops(self.document, folder))
                if out:
                    QMessageBox.information(self, "已导出单牙图与坐标变换", str(out))

    def _toggle_overlay(self):
        self.canvas.show_annotations = not self.canvas.show_annotations
        self.canvas.render()

    def _run(self):
        self.worker.send("run_image")

    def _models(self):
        device = self._health.get("actual_device") if self._health else "检查中"
        QMessageBox.information(self, "模型与设备", f"实际设备：{device}\n分割模型：尚未接入\nCEJ / 骨水平 / 根尖模型：尚未接入\n\n当前版本可手工标注、保存和导出。自动流程需要完成模型配置和验证。")

    def _worker_response(self, message):
        if "health" in message:
            self._health = message["health"]
            self.statusBar().showMessage("CPU 算子检查通过 · 自动模型尚未配置 · 全景片效果未评价")
            if self._probe_report:
                atomic_json(self._probe_report, {"gui_started": True, "worker_health": self._health,
                            "image_loaded": bool(self.document), "automatic_inference": "BLOCKED_WEIGHTS"})
                self._probe_report = None
        elif message["type"] == "error":
            self.statusBar().showMessage(message["user_message"])

    def closeEvent(self, event):
        dirty = [doc for doc in self.documents if doc.dirty]
        if dirty:
            answer = QMessageBox.question(self, "尚有未保存的修改", "关闭将丢弃未保存的修改。是否关闭？",
                                          QMessageBox.StandardButton.Discard | QMessageBox.StandardButton.Cancel,
                                          QMessageBox.StandardButton.Cancel)
            if answer != QMessageBox.StandardButton.Discard:
                event.ignore()
                return
        self.worker.stop()
        event.accept()


def run_gui(input_path=None, probe_report=None, screenshot_path=None, exit_after_probe=False):
    app = QApplication.instance() or QApplication([])
    app.setApplicationName("PanoDental")
    app.setOrganizationName("PanoDental")
    window = MainWindow()
    window._probe_report = Path(probe_report) if probe_report else None
    if input_path:
        window._guard(lambda: window.add_image(input_path))
    window.show()
    if screenshot_path:
        def capture():
            window.canvas.fit()
            window.grab().save(str(screenshot_path))
        QTimer.singleShot(2500, capture)
    if exit_after_probe:
        timer = QTimer(window)
        def check():
            if window._health:
                for doc in window.documents:
                    doc._saved_revision = doc.annotation.revision
                window.close()
                app.quit()
        timer.timeout.connect(check)
        timer.start(300)
        def probe_timeout():
            window.worker.stop()
            app.quit()
        QTimer.singleShot(90000, probe_timeout)
    return app.exec()
