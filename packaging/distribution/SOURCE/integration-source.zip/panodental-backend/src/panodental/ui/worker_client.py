import json
from pathlib import Path
import sys

from PySide6.QtCore import QProcess, QObject, Signal, QStandardPaths


class WorkerClient(QObject):
    response = Signal(dict)
    failure = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.process = QProcess(self)
        self.process.setProcessChannelMode(QProcess.ProcessChannelMode.SeparateChannels)
        self.process.readyReadStandardOutput.connect(self._read)
        self.process.readyReadStandardError.connect(self._log)
        self.process.errorOccurred.connect(lambda _: self.failure.emit("后台进程启动或通信失败"))
        self.buffer = b""
        self.sequence = 0
        self.log_path = Path(QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppLocalDataLocation)) / "worker.log"
        self.log_path.parent.mkdir(parents=True, exist_ok=True)

    def start(self):
        if getattr(sys, "frozen", False):
            self.process.setProgram(str(Path(sys.executable).with_name("PanoDentalWorker.exe")))
        else:
            self.process.setProgram(sys.executable)
            self.process.setArguments(["-m", "panodental.worker"])
        self.process.started.connect(lambda: self.send("health"))
        self.process.start()

    def send(self, command, **kwargs):
        self.sequence += 1
        self.process.write((json.dumps({"request_id": str(self.sequence), "command": command, **kwargs}, ensure_ascii=False)+"\n").encode("utf8"))

    def _read(self):
        self.buffer += bytes(self.process.readAllStandardOutput())
        while b"\n" in self.buffer:
            line, self.buffer = self.buffer.split(b"\n", 1)
            if line:
                try:
                    self.response.emit(json.loads(line))
                except (ValueError, UnicodeError):
                    self.failure.emit("后台返回了无效消息")

    def _log(self):
        data = bytes(self.process.readAllStandardError())
        if data:
            with self.log_path.open("ab") as stream:
                stream.write(data)

    def stop(self):
        if self.process.state() != QProcess.ProcessState.NotRunning:
            self.send("shutdown")
            if not self.process.waitForFinished(1500):
                self.process.terminate()
                if not self.process.waitForFinished(1000):
                    self.process.kill()
                    self.process.waitForFinished(1000)
