"""Shared desktop/CLI edit, project and export service. No model simulation."""

import csv
from hashlib import sha256
from io import BytesIO
import json
import math
import os
from pathlib import Path
import tempfile

from PIL import Image, ImageDraw

from .domain import Annotation, EditEvent, Landmark, Tooth, now, uid
from .imaging import CanonicalImage, read_image


def atomic_bytes(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".pending-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def atomic_json(path, value):
    data = json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2).encode("utf8")
    json.loads(data)
    atomic_bytes(path, data)


def safe_ref(root, ref):
    root = Path(root).resolve()
    resolved = (root / ref).resolve()
    if Path(ref).is_absolute() or not resolved.is_relative_to(root):
        raise ValueError("项目路径超出目录")
    return resolved


def contour_bbox(points):
    xs, ys = zip(*points)
    return min(xs), min(ys), max(xs)+1, max(ys)+1


class Document:
    def __init__(self, image, annotation=None, root=None):
        self.image = image
        self.annotation = annotation or Annotation(image=image.record)
        self.root = Path(root) if root else None
        self._saved_revision = self.annotation.revision if root else -1
        self._undo = []
        self._redo = []

    @classmethod
    def from_image(cls, path):
        return cls(read_image(path))

    @property
    def dirty(self):
        return self.annotation.revision != self._saved_revision

    def state(self):
        return self.annotation.model_dump(mode="json", exclude={"edits", "revision"})

    def _apply(self, action, object_id, state, track=True):
        before = self.state()
        revision = self.annotation.revision+1
        event = EditEvent(revision=revision, action=action, object_id=object_id, before=before, after=state)
        updated = Annotation.model_validate(dict(state, revision=revision,
                          edits=[e.model_dump(mode="json") for e in self.annotation.edits]+[event.model_dump(mode="json")]))
        if track:
            self._undo.append(before)
            self._redo.clear()
        self.annotation = updated

    def add_tooth(self, points):
        tooth = Tooth(contours=[points], bbox_xyxy=contour_bbox(points), review_status="edited")
        state = self.state()
        state["teeth"].append(tooth.model_dump(mode="json"))
        self._apply("add_tooth", tooth.instance_id, state)
        return tooth.instance_id

    def edit_contour(self, instance_id, points):
        state = self.state()
        tooth = next(t for t in state["teeth"] if t["instance_id"] == instance_id)
        tooth.update(contours=[points], bbox_xyxy=contour_bbox(points), review_status="edited", current_mask_ref=None)
        self._apply("edit_contour", instance_id, state)

    def delete_tooth(self, instance_id):
        state = self.state()
        state["teeth"] = [t for t in state["teeth"] if t["instance_id"] != instance_id]
        state["landmarks"] = [p for p in state["landmarks"] if p["instance_id"] != instance_id]
        self._apply("delete_tooth", instance_id, state)

    def set_fdi(self, instance_id, fdi):
        state = self.state()
        tooth = next(t for t in state["teeth"] if t["instance_id"] == instance_id)
        tooth.update(fdi=fdi, fdi_reviewed=True)
        for point in state["landmarks"]:
            if point["instance_id"] == instance_id:
                point["side_reviewed"] = False
        self._apply("set_fdi", instance_id, state)

    def add_point(self, instance_id, kind, xy, side="unknown", root_id=None):
        point = Landmark(instance_id=instance_id, kind=kind, current_xy=xy, side=side,
                         root_id=root_id, review_status="edited")
        state = self.state()
        state["landmarks"].append(point.model_dump(mode="json"))
        self._apply("add_point", point.landmark_id, state)
        return point.landmark_id

    def _point_change(self, point_id, action, **changes):
        state = self.state()
        point = next(p for p in state["landmarks"] if p["landmark_id"] == point_id)
        point.update(changes)
        self._apply(action, point_id, state)

    def move_point(self, point_id, xy):
        self._point_change(point_id, "move_point", current_xy=xy, location_status="present", review_status="edited")

    def set_point_status(self, point_id, status):
        if status == "present":
            raise ValueError("恢复定位需要明确坐标")
        self._point_change(point_id, "set_location_status", current_xy=None, location_status=status, review_status="edited")

    def delete_point(self, point_id):
        self._point_change(point_id, "reject_point", current_xy=None, location_status="missing", review_status="rejected")

    def restore_point(self, point_id):
        point = next(p for p in self.annotation.landmarks if p.landmark_id == point_id)
        if point.raw_xy is None:
            raise ValueError("此点没有模型原始预测")
        self._point_change(point_id, "restore_prediction", current_xy=point.raw_xy,
                           location_status="present", review_status="unreviewed")

    def accept_tooth(self, instance_id):
        state = self.state()
        next(t for t in state["teeth"] if t["instance_id"] == instance_id)["review_status"] = "accepted"
        for point in state["landmarks"]:
            if point["instance_id"] == instance_id and point["review_status"] != "rejected":
                point["review_status"] = "accepted"
        self._apply("accept_tooth", instance_id, state)

    def undo(self):
        if self._undo:
            self._redo.append(self.state())
            self._apply("undo", self.annotation.image.image_id, self._undo.pop(), track=False)

    def redo(self):
        if self._redo:
            self._undo.append(self.state())
            self._apply("redo", self.annotation.image.image_id, self._redo.pop(), track=False)

    def save(self, root=None):
        root = Path(root) if root else self.root
        if root is None:
            raise ValueError("请先选择项目保存目录")
        pointer_path = root / "project.json"
        if pointer_path.exists():
            pointer = json.loads(pointer_path.read_text(encoding="utf8"))
            if pointer["image_id"] != self.annotation.image.image_id:
                raise ValueError("此目录已有另一个影像项目")
            if self.root and root.resolve() == self.root.resolve() and pointer["revision"] != self._saved_revision:
                raise ValueError("项目已由其他窗口更新，请另存或重新打开")
        self.annotation = Annotation.model_validate(self.annotation.model_dump())
        canonical_ref = "images/canonical" + self.image.canonical_extension
        original_ref = "originals/source" + Path(self.annotation.image.source_name).suffix.lower()
        for ref, data in ((canonical_ref, self.image.canonical_bytes), (original_ref, self.image.original_bytes)):
            target = safe_ref(root, ref)
            if target.exists() and sha256(target.read_bytes()).hexdigest() != sha256(data).hexdigest():
                raise ValueError("源图内容冲突，保存已停止")
            if not target.exists():
                atomic_bytes(target, data)
        annotation_ref = f"annotations/revision-{self.annotation.revision:06d}.json"
        snapshot = self.annotation.model_dump(mode="json")
        if safe_ref(root, annotation_ref).exists():
            previous = json.loads(safe_ref(root, annotation_ref).read_text(encoding="utf8"))
            if previous != snapshot:
                raise ValueError("已有修订内容冲突，拒绝覆盖")
        else:
            atomic_json(safe_ref(root, annotation_ref), snapshot)
        atomic_json(pointer_path, {"schema_version": "1.0", "image_id": self.annotation.image.image_id,
                    "revision": self.annotation.revision, "annotation_ref": annotation_ref,
                    "canonical_ref": canonical_ref, "original_ref": original_ref})
        self.root = root
        self._saved_revision = self.annotation.revision
        return root

    @classmethod
    def open(cls, root):
        root = Path(root)
        pointer = json.loads((root / "project.json").read_text(encoding="utf8"))
        if pointer.get("schema_version") != "1.0":
            raise ValueError("不支持的项目版本")
        annotation = Annotation.model_validate_json(safe_ref(root, pointer["annotation_ref"]).read_bytes())
        if pointer["revision"] != annotation.revision or pointer["image_id"] != annotation.image.image_id:
            raise ValueError("项目修订不一致")
        raw = safe_ref(root, pointer["original_ref"]).read_bytes()
        canonical = safe_ref(root, pointer["canonical_ref"]).read_bytes()
        if sha256(raw).hexdigest() != annotation.image.original_sha256 or sha256(canonical).hexdigest() != annotation.image.canonical_sha256:
            raise ValueError("项目图像哈希不匹配")
        with Image.open(BytesIO(canonical)) as im:
            pixels = im.copy()
        if pixels.size != (annotation.image.width, annotation.image.height):
            raise ValueError("项目图像尺寸不匹配")
        image = CanonicalImage(pixels, raw, canonical, Path(pointer["canonical_ref"]).suffix, annotation.image)
        return cls(image, annotation, root)

    def mask(self, tooth):
        if tooth.current_mask_ref:
            if not self.root:
                raise ValueError("掩膜文件没有所属项目")
            with Image.open(safe_ref(self.root, tooth.current_mask_ref)) as im:
                if im.size != self.image.pixels.size:
                    raise ValueError("掩膜尺寸不匹配")
                return im.convert("L")
        mask = Image.new("L", self.image.pixels.size, 0)
        draw = ImageDraw.Draw(mask)
        for contour in tooth.contours:
            draw.polygon([(math.floor(x+.5), math.floor(y+.5)) for x, y in contour], fill=255)
        return mask

    def overlay(self):
        image = self.image.rgb8()
        draw = ImageDraw.Draw(image)
        for tooth in self.annotation.teeth:
            for contour in tooth.contours:
                draw.line(list(contour)+[contour[0]], fill=(80, 210, 155), width=2)
        colors = {"cej": (250, 190, 50), "bone_level": (70, 190, 255), "apex": (255, 100, 160)}
        for point in self.annotation.landmarks:
            if point.current_xy is not None and point.review_status != "rejected":
                x, y = point.current_xy
                draw.ellipse((x-3, y-3, x+3, y+3), fill=colors[point.kind])
        return image

    def export(self, destination):
        destination = Path(destination)
        destination.mkdir(parents=True, exist_ok=True)
        folder = destination / f"export-r{self.annotation.revision}-{uid()[:8]}"
        folder.mkdir()
        atomic_json(folder / "annotations.json", self.annotation.model_dump(mode="json"))
        atomic_bytes(folder / ("canonical"+self.image.canonical_extension), self.image.canonical_bytes)
        fields = ["image_id", "instance_id", "fdi", "kind", "side", "root_id", "raw_x", "raw_y", "current_x", "current_y",
                  "location_status", "review_status", "origin", "model_id", "run_id"]
        with (folder / "landmarks.csv").open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fields)
            writer.writeheader()
            teeth = {t.instance_id: t for t in self.annotation.teeth}
            for point in self.annotation.landmarks:
                row = {k: getattr(point, k, None) for k in fields}
                row.update(image_id=self.annotation.image.image_id, fdi=teeth[point.instance_id].fdi,
                           raw_x=(point.raw_xy or (None, None))[0], raw_y=(point.raw_xy or (None, None))[1],
                           current_x=(point.current_xy or (None, None))[0], current_y=(point.current_xy or (None, None))[1])
                writer.writerow({k: "'"+v if isinstance(v, str) and v.lstrip().startswith(("=", "+", "-", "@")) else v for k, v in row.items()})
        (folder / "masks").mkdir()
        for tooth in self.annotation.teeth:
            self.mask(tooth).save(folder / "masks" / f"{tooth.instance_id}.png")
        self.overlay().save(folder / "overlay.png")
        files = {str(p.relative_to(folder)): sha256(p.read_bytes()).hexdigest() for p in folder.rglob("*") if p.is_file()}
        atomic_json(folder / "manifest.json", {"image_id": self.annotation.image.image_id, "revision": self.annotation.revision,
                    "created_at": now(), "units": "canonical_image_pixels", "domain_validation": "panoramic_unvalidated",
                    "has_unreviewed": any(p.review_status == "unreviewed" for p in self.annotation.landmarks), "files": files})
        return folder
