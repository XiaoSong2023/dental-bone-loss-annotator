"""Export real unpainted image crops and exact mappings for selected teeth."""

from pathlib import Path

from .domain import uid
from .geometry import Transform, plan_roi
from .project import atomic_json


def export_crops(document, destination):
    root = Path(destination) / ("tooth-crops-"+uid()[:8])
    root.mkdir(parents=True)
    records = []
    for tooth in document.annotation.teeth:
        box = plan_roi(tooth.bbox_xyxy, document.image.pixels.size)
        crop = document.image.pixels.crop(box)
        transform = Transform.crop_resize(box, crop.size)
        name = tooth.instance_id + document.image.canonical_extension
        crop.save(root / name)
        records.append({"instance_id": tooth.instance_id, "fdi": tooth.fdi, "image_ref": name,
                        "tooth_origin": tooth.origin, "crop_xyxy": list(box), "crop_size": list(crop.size),
                        "canonical_to_crop": transform.matrix.tolist(), "crop_to_canonical": transform.inverse().matrix.tolist(),
                        "orientation_normalized": False, "preprocessing_profile": "context_crop_v1_experimental",
                        "has_keypoint_prediction": False})
    atomic_json(root / "crops.json", {"image_id": document.annotation.image.image_id,
                "source_sha256": document.annotation.image.canonical_sha256, "revision": document.annotation.revision,
                "coordinate_space": "canonical_image_pixel_centers", "teeth": records})
    return root
