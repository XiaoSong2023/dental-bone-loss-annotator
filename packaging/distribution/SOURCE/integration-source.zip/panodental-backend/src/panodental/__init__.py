"""PanoDental: local image annotation, with explicit model provenance."""

__version__ = "0.1.0"
