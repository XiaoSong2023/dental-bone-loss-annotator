"""Local UTF-8 JSONL worker. Missing assets never produce simulated detections."""

from contextlib import redirect_stdout
import json
import sys
import traceback

from .runtime import health


def dispatch(request):
    base = {"request_id": request.get("request_id"), "stage": "capabilities"}
    command = request.get("command")
    if command == "health":
        return base | {"type": "result", "health": health()}
    if command == "capabilities":
        return base | {"type": "result", "device": "cpu", "manual_annotation": True,
                       "segmentation": "missing_trained_weights", "landmarks": "missing_trained_weights"}
    if command in {"load_models", "run_image"}:
        return base | {"type": "error", "error_code": "MISSING_TRAINED_WEIGHTS", "recoverable": True,
                       "user_message": "尚未配置完整的牙科分割及 CEJ、骨水平、根尖模型，暂不能执行自动推理。"}
    if command == "cancel":
        return base | {"type": "cancelled", "message": "当前没有正在运行的模型任务"}
    if command == "shutdown":
        return base | {"type": "shutdown"}
    return base | {"type": "error", "error_code": "INVALID_COMMAND", "recoverable": True,
                   "user_message": "未知 Worker 命令"}


def main():
    if hasattr(sys.stdin, "reconfigure"):
        sys.stdin.reconfigure(encoding="utf8")
        sys.stdout.reconfigure(encoding="utf8")
        sys.stderr.reconfigure(encoding="utf8")
    for line in sys.stdin:
        request = {}
        try:
            request = json.loads(line)
            if not isinstance(request, dict):
                raise ValueError("消息必须是 JSON 对象")
            with redirect_stdout(sys.stderr):
                response = dispatch(request)
        except Exception:
            traceback.print_exc(file=sys.stderr)
            response = {"request_id": request.get("request_id") if isinstance(request, dict) else None,
                        "type": "error", "error_code": "WORKER_ERROR", "recoverable": True,
                        "user_message": "设备检查或消息处理失败，请查看本地日志"}
        print(json.dumps(response, ensure_ascii=False, allow_nan=False), flush=True)
        if response["type"] == "shutdown":
            break
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
