"""Validated annotation contract. All primary coordinates are canonical pixels."""

from datetime import datetime, timezone
from typing import Annotated, Literal
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field, FiniteFloat, model_validator

Point = tuple[FiniteFloat, FiniteFloat]
Kind = Literal["cej", "bone_level", "apex"]
Side = Literal["unknown", "image_left", "image_right", "mesial", "distal", "central"]
Review = Literal["unreviewed", "accepted", "edited", "rejected"]
Location = Literal["present", "missing", "not_visible", "ambiguous", "not_applicable"]


def uid():
    return uuid4().hex


def now():
    return datetime.now(timezone.utc).isoformat()


class Record(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class ImageRecord(Record):
    image_id: str = Field(default_factory=uid)
    source_name: str
    original_sha256: str
    canonical_sha256: str
    width: int = Field(gt=0)
    height: int = Field(gt=0)
    bit_depth: Literal[8, 16]
    exif_orientation: int = Field(default=1, ge=1, le=8)
    original_to_canonical: list[list[FiniteFloat]]
    canonical_to_original: list[list[FiniteFloat]]
    direction_confirmed: bool = False
    coordinate_space: Literal["canonical_image_pixel_centers"] = "canonical_image_pixel_centers"


class Tooth(Record):
    instance_id: str = Field(default_factory=uid)
    fdi: int | None = None
    fdi_reviewed: bool = False
    bbox_xyxy: tuple[FiniteFloat, FiniteFloat, FiniteFloat, FiniteFloat]
    contours: list[list[Point]]
    raw_contours: list[list[Point]] = Field(default_factory=list)
    raw_mask_ref: str | None = None
    current_mask_ref: str | None = None
    segmentation_score: FiniteFloat | None = None
    origin: Literal["manual", "model"] = "manual"
    review_status: Review = "unreviewed"

    @model_validator(mode="after")
    def valid(self):
        if self.fdi is not None and not (11 <= self.fdi <= 48 and self.fdi // 10 in range(1, 5) and self.fdi % 10 in range(1, 9)
                                          or 51 <= self.fdi <= 85 and self.fdi // 10 in range(5, 9) and self.fdi % 10 in range(1, 6)):
            raise ValueError("FDI 牙位无效")
        x1, y1, x2, y2 = self.bbox_xyxy
        if x1 >= x2 or y1 >= y2 or not self.contours or any(len(c) < 3 for c in self.contours):
            raise ValueError("牙齿轮廓至少3个点，框须有面积")
        return self


class Landmark(Record):
    landmark_id: str = Field(default_factory=uid)
    instance_id: str
    kind: Kind
    side: Side = "unknown"
    side_reviewed: bool = False
    root_id: str | None = None
    raw_xy: Point | None = None
    suggested_xy: Point | None = None
    current_xy: Point | None = None
    location_status: Location = "present"
    review_status: Review = "unreviewed"
    origin: Literal["manual", "model", "postprocess_suggestion"] = "manual"
    object_score: FiniteFloat | None = None
    keypoint_score: FiniteFloat | None = None
    model_id: str | None = None
    run_id: str | None = None
    transform_id: str | None = None

    @model_validator(mode="after")
    def valid(self):
        if (self.location_status == "present") != (self.current_xy is not None):
            raise ValueError("可定位点必须有坐标，缺失/不可判读点必须为 null")
        if self.origin == "model" and (self.raw_xy is None or not self.run_id or not self.model_id):
            raise ValueError("模型点必须有原始坐标、run_id 和 model_id")
        return self


class EditEvent(Record):
    event_id: str = Field(default_factory=uid)
    revision: int
    timestamp: str = Field(default_factory=now)
    actor: str = "local_user"
    action: str
    object_id: str
    before: dict
    after: dict


class Annotation(Record):
    schema_version: Literal["1.0"] = "1.0"
    image: ImageRecord
    revision: int = Field(default=0, ge=0)
    domain_validation: Literal["panoramic_unvalidated"] = "panoramic_unvalidated"
    teeth: list[Tooth] = Field(default_factory=list)
    landmarks: list[Landmark] = Field(default_factory=list)
    edits: list[EditEvent] = Field(default_factory=list)

    @model_validator(mode="after")
    def relationships(self):
        ids = [t.instance_id for t in self.teeth]
        point_ids = [p.landmark_id for p in self.landmarks]
        if len(set(ids)) != len(ids) or len(set(point_ids)) != len(point_ids):
            raise ValueError("实例/点 ID 重复")
        for point in self.landmarks:
            if point.instance_id not in ids:
                raise ValueError("点引用不存在的牙齿")
            for xy in (point.current_xy, point.raw_xy, point.suggested_xy):
                if xy is not None and not (0 <= xy[0] <= self.image.width - 1 and 0 <= xy[1] <= self.image.height - 1):
                    raise ValueError("点超出原图范围")
        for tooth in self.teeth:
            x1, y1, x2, y2 = tooth.bbox_xyxy
            if not (0 <= x1 < x2 <= self.image.width and 0 <= y1 < y2 <= self.image.height):
                raise ValueError("牙齿框超出原图范围")
            for contour in tooth.contours:
                if any(not (0 <= x < self.image.width and 0 <= y < self.image.height) for x, y in contour):
                    raise ValueError("轮廓超出原图范围")
        return self
