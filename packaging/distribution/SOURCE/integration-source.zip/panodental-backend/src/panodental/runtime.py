"""Health checks exercise CPU operators only, never an untrained dental network."""

from contextlib import redirect_stdout
import platform
import sys


def health():
    with redirect_stdout(sys.stderr):
        import torch
        import torchvision
        from torchvision.ops import nms, roi_align
        torch.set_num_threads(2)
        boxes = torch.tensor([[0., 0., 8., 8.], [1., 1., 7., 7.]])
        selected = nms(boxes, torch.tensor([.9, .8]), .5)
        aligned = roi_align(torch.ones((1, 1, 8, 8)), [boxes[:1]], (2, 2), aligned=True)
        if selected.tolist() != [0] or tuple(aligned.shape) != (1, 1, 2, 2) or not torch.isfinite(aligned).all():
            raise RuntimeError("CPU torchvision 算子检查失败")
        return {"platform": platform.system(), "architecture": platform.machine(),
                "python": platform.python_version(), "torch": torch.__version__,
                "torchvision": torchvision.__version__, "torch_cuda_build": torch.version.cuda,
                "actual_device": "cpu", "cpu_ops": "passed", "trained_models": "missing",
                "dental_inference": "NOT_RUN", "frozen": bool(getattr(sys, "frozen", False))}
