"""Read archive metadata without importing upstream code or unpickling models."""

from collections import Counter
from hashlib import file_digest, sha256
from io import BytesIO
import json
from pathlib import Path
import pickletools
import platform
import sys
import zipfile


def checkpoint_metadata(data: bytes) -> dict:
    result = {"bytes": len(data), "sha256": sha256(data).hexdigest()}
    if data.startswith(b"version https://git-lfs.github.com/spec/"):
        return result | {"format": "git_lfs_pointer", "usable": False}
    if not zipfile.is_zipfile(BytesIO(data)):
        return result | {"format": "unknown_not_deserialized", "usable": False}
    with zipfile.ZipFile(BytesIO(data)) as archive:
        names = [n for n in archive.namelist() if n.endswith("/data.pkl") or n == "data.pkl"]
        if len(names) != 1:
            return result | {"format": "zip_without_unique_data_pickle", "usable": False}
        # pickletools interprets opcodes only; it never imports GLOBALs or executes REDUCE.
        ops = list(pickletools.genops(archive.read(names[0])))
    strings = [arg for op, arg, _ in ops if op.name in {"BINUNICODE", "SHORT_BINUNICODE", "UNICODE"}]
    globals_ = sorted({arg for op, arg, _ in ops if op.name == "GLOBAL"})
    nc_literals = []
    for index, (_, arg, _) in enumerate(ops):
        if arg == "nc":
            next_values = [(op.name, value) for op, value, _ in ops[index + 1:index + 4]
                           if op.name not in {"BINPUT", "LONG_BINPUT", "MEMOIZE"}]
            if next_values and next_values[0][0] in {"BININT", "BININT1", "BININT2", "INT"}:
                nc_literals.append(next_values[0][1])
    coco = all(name in strings for name in ("person", "bicycle", "car", "toothbrush", "coco.yaml"))
    return result | {
        "format": "pytorch_zip_with_pickle", "deserialized": False,
        "globals": globals_, "nc_literal_evidence": nc_literals,
        "config_strings": [s for s in strings if s.endswith(".yaml")],
        "coco_metadata": coco,
        "dental_status": "REJECTED_COCO" if coco else "REQUIRES_MANUAL_AUDIT",
        "usable": False,  # Metadata alone never certifies a trained compatible dental model.
    }


def audit_workspace(workspace: Path) -> dict:
    workspace = workspace.resolve()
    archives = []
    materials = workspace / "牙周视觉yolov8-seg跟3点标注系统代码"
    for path in sorted(materials.rglob("*.zip")):
        with path.open("rb") as stream:
            digest = file_digest(stream, "sha256").hexdigest()
        with zipfile.ZipFile(path) as archive:
            files = [info for info in archive.infolist() if not info.is_dir()]
            weights = []
            for info in files:
                if Path(info.filename).suffix.lower() in {".pt", ".pth", ".ckpt"}:
                    weights.append({"entry": info.filename, **checkpoint_metadata(archive.read(info))})
            archives.append({
                "path": str(path.relative_to(workspace)), "sha256": digest,
                "bytes": path.stat().st_size, "file_count": len(files),
                "extensions": dict(Counter(Path(info.filename).suffix.lower() for info in files)),
                "weights": weights,
            })
    return {
        "audit_type": "static_no_model_execution",
        "platform": platform.system(), "architecture": platform.machine(),
        "python": platform.python_version(), "archives": archives,
        "model_inference": "NOT_RUN", "dental_accuracy": "NOT_EVALUATED",
    }


def main(argv=None) -> int:
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = audit_workspace(args.workspace)
    content = json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(content, encoding="utf-8")
    else:
        print(content)
    return 0


if __name__ == "__main__":
    sys.exit(main())
