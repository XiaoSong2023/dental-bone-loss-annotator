from dataclasses import dataclass
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import numpy as np
from PIL import Image, ImageOps

from .domain import ImageRecord
from .geometry import exif_transform


@dataclass
class CanonicalImage:
    pixels: Image.Image
    original_bytes: bytes
    canonical_bytes: bytes
    canonical_extension: str
    record: ImageRecord

    def rgb8(self):
        if self.record.bit_depth == 16:
            # Fixed full-range display conversion; the saved canonical image retains all 16 bits.
            pixels = np.asarray(self.pixels, dtype=np.float64)
            return Image.fromarray(np.rint(np.clip(pixels, 0, 65535)/257).astype(np.uint8)).convert("RGB")
        return self.pixels.convert("RGB")


def read_image(path):
    path = Path(path)
    raw = path.read_bytes()
    with Image.open(BytesIO(raw)) as source:
        if source.format not in {"PNG", "JPEG", "BMP", "TIFF"}:
            raise ValueError("仅支持 PNG、JPEG、BMP、单帧 TIFF")
        if getattr(source, "n_frames", 1) != 1:
            raise ValueError("仅支持单帧影像")
        orientation = source.getexif().get(274, 1)
        transform, size = exif_transform(orientation, *source.size)
        source.load()
        source_array = np.asarray(source)
        bit_depth = 16 if source.mode.startswith("I;16") or source.mode == "I" and source_array.dtype.itemsize >= 2 else 8
        pixels = ImageOps.exif_transpose(source).copy()
        if bit_depth == 16:
            arr = np.asarray(pixels)
            if arr.min() < 0 or arr.max() > 65535:
                raise ValueError("不支持超出 16 位范围的整型影像")
            pixels = Image.fromarray(arr.astype(np.uint16))
        elif pixels.mode not in {"L", "RGB"}:
            pixels = pixels.convert("RGB")
    pixels.info.clear()
    encoded = BytesIO()
    extension = ".tiff" if bit_depth == 16 else ".png"
    pixels.save(encoded, format="TIFF" if bit_depth == 16 else "PNG")
    canonical = encoded.getvalue()
    record = ImageRecord(source_name=path.name, original_sha256=sha256(raw).hexdigest(),
                         canonical_sha256=sha256(canonical).hexdigest(), width=size[0], height=size[1],
                         bit_depth=bit_depth, exif_orientation=orientation,
                         original_to_canonical=transform.matrix.tolist(),
                         canonical_to_original=transform.inverse().matrix.tolist())
    return CanonicalImage(pixels, raw, canonical, extension, record)
