"""Offline, audited community-model inference in canonical image coordinates.

This module deliberately imports ML runtimes only inside the inference functions.
Run it in a disposable worker process: cancelling a forward pass requires terminating
that worker. Checkpoints are fixed, checked, and never loaded as full-object pickle.
"""
from __future__ import annotations

import argparse
import copy
import ctypes
from datetime import datetime, timezone
import gc
import hashlib
import json
import os
from pathlib import Path
import time
import uuid

import numpy as np
from PIL import Image, ImageDraw

from .geometry import plan_roi
from .imaging import read_image
from .boundary import project_teeth


SEGMENTATION = {
    "repo": "chocodo/teeth-segmentation-odontoai",
    "revision": "4867533fb8e8ccd115c10c533a238e4288757165",
    "filename": "best.pth",
    "sha256": "37bb200f5aa6620fc58fe549d8babd0080b6d2b661d1e33ec452ea3f329f7012",
    "architecture": "torchvision Mask R-CNN ResNet50 FPN, 53 classes",
}
POSE = {
    "repo": "rummanadib023/denpar-bone-loss-v2",
    "revision": "d254abd6df9ab41c0367b99457334d7f1ea69895",
    "filename": "surf_pose.onnx",
    "sha256": "60d14e5b6560cbf834ffd0a6aff0c0558390224bbe1902199931479bfb89ad98",
    "architecture": "YOLOv8m-pose ONNX, one tooth surface, CEJ/bone-level/apex",
}
# Explicit publisher class table. Background is index zero.
FDI_CLASSES = [None, 11, 12, 13, 14, 15, 16, 17, 18,
               21, 22, 23, 24, 25, 26, 27, 28,
               31, 32, 33, 34, 35, 36, 37, 38,
               41, 42, 43, 44, 45, 46, 47, 48,
               51, 52, 53, 54, 55, 61, 62, 63, 64, 65,
               71, 72, 73, 74, 75, 81, 82, 83, 84, 85]
POINT_KINDS = ("cej", "bone_level", "apex")


class InferenceCancelled(RuntimeError):
    pass


def _json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    temporary.replace(path)


def _check_cancelled(cancelled):
    if cancelled is not None and cancelled():
        raise InferenceCancelled("自动分析已取消")


def _peak_working_set():
    if os.name != "nt":
        return None
    class MemoryCounters(ctypes.Structure):
        _fields_ = [("cb", ctypes.c_ulong), ("faults", ctypes.c_ulong)] + [
            (name, ctypes.c_size_t) for name in ("peak_working_set", "working_set", "peak_paged_pool",
            "paged_pool", "peak_nonpaged_pool", "nonpaged_pool", "pagefile_usage", "peak_pagefile_usage")]
    counters = MemoryCounters()
    counters.cb = ctypes.sizeof(counters)
    if not ctypes.windll.psapi.GetProcessMemoryInfo(ctypes.c_void_p(-1), ctypes.byref(counters), counters.cb):
        return None
    return counters.peak_working_set / 2**30


def verified_model_path(model_dir, specification):
    path = Path(model_dir) / specification["repo"].replace("/", "--") / specification["filename"]
    if not path.is_file():
        raise FileNotFoundError(f"缺少已训练模型：{path}")
    with path.open("rb") as stream:
        actual = hashlib.file_digest(stream, "sha256").hexdigest()
    if actual != specification["sha256"]:
        raise ValueError(f"模型校验失败，不加载未知文件：{path.name}")
    return path


def letterbox_rgb(rgb, size=768):
    """Ultralytics fixed-size letterbox; coordinates use ratio, not half-pixel resize."""
    import cv2
    height, width = rgb.shape[:2]
    if height <= 0 or width <= 0:
        raise ValueError("Empty crop")
    ratio = min(size / width, size / height)
    resized = (round(width * ratio), round(height * ratio))
    dw, dh = (size - resized[0]) / 2, (size - resized[1]) / 2
    left, top = round(dw - .1), round(dh - .1)
    network = cv2.resize(rgb, resized, interpolation=cv2.INTER_LINEAR)
    network = cv2.copyMakeBorder(network, top, round(dh + .1), left, round(dw + .1),
                                cv2.BORDER_CONSTANT, value=(114, 114, 114))
    tensor = np.ascontiguousarray(network.transpose(2, 0, 1)[None], dtype=np.float32) / 255
    return tensor, {"ratio": ratio, "padding_left_top": [left, top],
                    "resized_width_height": list(resized), "input_width_height": [width, height],
                    "input_to_network": [[ratio, 0, left], [0, ratio, top], [0, 0, 1]]}


def decode_pose(output, transform, crop_box, image_size):
    """Preserve every score-filtered, NMS-retained surface and explain rejection."""
    import cv2
    if output.shape != (1, 14, 12096) or not np.isfinite(output).all():
        raise ValueError("Unexpected/non-finite pose output")
    raw = output[0].T
    indices = np.flatnonzero(raw[:, 4] >= .25)
    if not len(indices):
        return []
    candidates = raw[indices]
    boxes = candidates[:, :4].copy()
    boxes[:, :2] -= boxes[:, 2:] / 2
    selected = np.asarray(cv2.dnn.NMSBoxes(boxes.tolist(), candidates[:, 4].tolist(), .25, .5)).reshape(-1)
    surfaces = []
    for index in selected:
        row = candidates[int(index)]
        points = row[5:].reshape(3, 3)
        view_xy = (points[:, :2].astype(np.float64) - transform["padding_left_top"]) / transform["ratio"]
        view_to_crop = np.array(transform.get("view_to_crop", np.eye(3)), dtype=np.float64)
        crop_xy = (np.column_stack([view_xy, np.ones(3)]) @ view_to_crop.T)[:, :2]
        xy = crop_xy + np.array(crop_box[:2])
        reason = None
        if np.any(points[:, 2] < .30):
            reason = "point_score_below_0.30"
        elif (np.any(crop_xy < -1e-4) or np.any(crop_xy[:, 0] > crop_box[2] - crop_box[0] - 1 + 1e-4)
              or np.any(crop_xy[:, 1] > crop_box[3] - crop_box[1] - 1 + 1e-4)):
            reason = "point_outside_crop"
        elif (np.any(xy < -1e-4) or np.any(xy[:, 0] > image_size[0] - 1 + 1e-4)
              or np.any(xy[:, 1] > image_size[1] - 1 + 1e-4)):
            reason = "point_outside_image"
        surfaces.append({
            "prediction_index": int(indices[int(index)]), "object_score": float(row[4]),
            "side": "unknown", "accepted": reason is None, "rejection_reason": reason,
            "raw_network_box_xywh": row[:4].tolist(), "raw_network_keypoints": points.tolist(),
            "points": {kind: {"xy": (np.clip(p, [0, 0], np.array(image_size)-1) if reason is None else p).tolist(),
                               "raw_xy": p.tolist(), "score": float(score), "crop_xy": local.tolist()}
                       for kind, p, score, local in zip(POINT_KINDS, xy, points[:, 2], crop_xy)},
        })
    return surfaces


def _load_segmentation(path):
    import torch
    from torchvision.models.detection import MaskRCNN
    from torchvision.models.detection.backbone_utils import resnet_fpn_backbone
    from torchvision.ops import FrozenBatchNorm2d
    torch.set_num_threads(2)
    # Build on meta and assign audited state tensors; no random parameters survive.
    # FrozenBatchNorm is required to match the publisher's COCO-initialized backbone.
    with torch.device("meta"):
        backbone = resnet_fpn_backbone(backbone_name="resnet50", weights=None, trainable_layers=3)
        model = MaskRCNN(backbone, num_classes=53, min_size=800, max_size=1333,
                        box_nms_thresh=.5, box_score_thresh=.3, box_detections_per_img=60)
    state = torch.load(path, map_location="cpu", weights_only=True, mmap=True)
    if not isinstance(state, dict) or not all(isinstance(v, torch.Tensor) for v in state.values()):
        raise ValueError("Expected tensor-only segmentation state_dict")
    model.load_state_dict(state, strict=True, assign=True)
    # maskrcnn_resnet50_fpn(COCO_V1) uses overwrite_eps(..., 0.0) upstream.
    # Epsilon is not in state_dict and must be matched separately.
    for module in model.modules():
        if isinstance(module, FrozenBatchNorm2d):
            module.eps = 0.
    del state
    return model.eval()


def _segment(rgb, path, output_dir, cancelled):
    import cv2
    import torch
    import torchvision
    cv2.setNumThreads(2)
    model = _load_segmentation(path)
    lab = cv2.cvtColor(rgb, cv2.COLOR_RGB2LAB)
    lab[:, :, 0] = cv2.createCLAHE(clipLimit=2., tileGridSize=(8, 8)).apply(lab[:, :, 0])
    enhanced = cv2.cvtColor(lab, cv2.COLOR_LAB2RGB)
    tensor = torch.from_numpy(np.ascontiguousarray(enhanced.transpose(2, 0, 1))).float().div_(255)
    start = time.perf_counter()
    with torch.inference_mode():
        prediction = model([tensor])[0]
    forward = time.perf_counter() - start
    del model, tensor, enhanced, lab
    gc.collect()
    _check_cancelled(cancelled)
    raw_dir = output_dir / "raw_segmentation"
    raw_dir.mkdir()
    np.savez_compressed(raw_dir / "detections.npz", boxes=prediction["boxes"].numpy(),
                        labels=prediction["labels"].numpy(), scores=prediction["scores"].numpy())
    teeth, masks, rejected = [], [], []
    # Native output is score-ordered. Additional class-agnostic mask overlap pruning
    # prevents two FDI predictions for the same physical tooth; retain rejection evidence.
    for index in range(len(prediction["scores"])):
        _check_cancelled(cancelled)
        probabilities = prediction["masks"][index, 0].numpy()
        np.savez_compressed(raw_dir / f"mask_probability_{index:03}.npz", probability=probabilities)
        mask = np.asarray(probabilities > .5, dtype=np.uint8)
        label = int(prediction["labels"][index])
        if not 1 <= label < len(FDI_CLASSES):
            raise ValueError("Unknown FDI class from verified segmentation model")
        if not mask.any():
            rejected.append({"prediction_index": index, "reason": "empty_thresholded_mask"})
            continue
        duplicate = None
        for existing, existing_mask in zip(teeth, masks):
            intersection = np.count_nonzero(mask & existing_mask)
            union = np.count_nonzero(mask | existing_mask)
            if union and intersection / union >= .65:
                duplicate = existing["instance_id"]
                break
        if duplicate:
            rejected.append({"prediction_index": index, "reason": "duplicate_mask_iou_at_least_0.65",
                             "retained_instance_id": duplicate})
            continue
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        contours = [cv2.approxPolyDP(c, .7, True).reshape(-1, 2).tolist() for c in contours if len(c) >= 3]
        contours = [c for c in contours if len(c) >= 3]
        if not contours:
            rejected.append({"prediction_index": index, "reason": "no_valid_contour"})
            continue
        instance = f"tooth_{index:03}"
        mask_ref = f"masks/{instance}.png"
        (output_dir / "masks").mkdir(exist_ok=True)
        Image.fromarray(mask * 255).save(output_dir / mask_ref)
        teeth.append({"instance_id": instance, "prediction_index": index, "fdi": FDI_CLASSES[label],
                      "class_index": label, "score": float(prediction["scores"][index]),
                      "bbox_xyxy": prediction["boxes"][index].tolist(), "contours": contours,
                      "mask_ref": mask_ref, "surfaces": [], "review_status": "unreviewed"})
        masks.append(mask)
    native_count = len(prediction["scores"])
    del prediction
    gc.collect()
    return teeth, masks, {"forward_seconds": forward, "native_detection_count": native_count,
                          "retained_tooth_count": len(teeth), "rejected": rejected,
                          "torch": torch.__version__, "torchvision": torchvision.__version__,
                          "frozen_batch_norm_eps": 0.,
                          "raw_ref": "raw_segmentation/detections.npz"}


def surface_to_tooth(surface, teeth, distance_maps):
    """Associate CEJ/apex to nearest segmented tooth, with a width-relative distance gate.

    Bone level may lie outside the tooth mask, so it cannot anchor tooth association.
    Unknown/ambiguous surfaces stay in the raw record and are not presented as assigned.
    """
    anchor_points = np.array([surface["points"][kind]["xy"] for kind in ("cej", "apex")])
    costs = []
    for tooth, distance in zip(teeth, distance_maps):
        x1, _, x2, _ = tooth["bbox_xyxy"]
        width = max(x2 - x1, 1.)
        positions = np.rint(anchor_points).astype(int)
        xs = np.clip(positions[:, 0], 0, distance.shape[1] - 1)
        ys = np.clip(positions[:, 1], 0, distance.shape[0] - 1)
        distances = distance[ys, xs] / width
        costs.append((float(distances.mean()), float(distances.max())))
    if not costs:
        return None, {"reason": "no_segmented_teeth"}
    order = sorted(range(len(costs)), key=lambda i: costs[i][0])
    best = order[0]
    if costs[best][1] > .35:
        return None, {"reason": "anchors_too_far_from_tooth", "best_normalized_distance": costs[best][1]}
    # Do not invent near/distal labels or assign a tie arbitrarily.
    if len(order) > 1 and costs[order[1]][0] - costs[best][0] < .03:
        return None, {"reason": "ambiguous_tooth_association", "best_mean_distance": costs[best][0]}
    return teeth[best]["instance_id"], {"method": "cej_apex_distance_to_segmentation",
                                       "normalized_mean_distance": costs[best][0],
                                       "normalized_max_distance": costs[best][1]}


def merge_surface_candidate(tooth, surface):
    """Deduplicate views of one physical surface while keeping separate tooth sides.

    All inference rows remain in raw_pose. This selection compares complete model
    triplets, never synthesizes coordinates or combines points from different rows.
    """
    points = np.array([surface["points"][kind]["raw_xy"] for kind in POINT_KINDS])
    width = tooth["bbox_xyxy"][2] - tooth["bbox_xyxy"][0]
    root_length = float(np.linalg.norm(points[0] - points[2]))
    for index, existing in enumerate(tooth["surfaces"]):
        old = np.array([existing["points"][kind]["raw_xy"] for kind in POINT_KINDS])
        old_length = float(np.linalg.norm(old[0] - old[2]))
        differences = np.linalg.norm(points - old, axis=1)
        if differences[0] <= max(2., .15 * width) and differences.max() <= max(2., .10 * min(root_length, old_length)):
            keep_new = surface["object_score"] > existing["object_score"]
            retained = surface if keep_new else existing
            suppressed = existing if keep_new else surface
            if keep_new:
                tooth["surfaces"][index] = copy.deepcopy(surface)
            tooth.setdefault("surface_selection", []).append({
                "method": "model_triplet_position_deduplication",
                "retained_surface_id": retained["surface_id"],
                "suppressed_surface_id": suppressed["surface_id"],
                "triplet_max_distance_px": float(differences.max()),
                "selection": "higher_model_object_score_without_point_averaging",
            })
            return keep_new
    tooth["surfaces"].append(copy.deepcopy(surface))
    return True


def _pose(rgb, teeth, masks, path, output_dir, progress, cancelled, roi_margin=(.25, .15),
          rotation=0, skip_complete=False, raw_folder="raw_pose"):
    import cv2
    import onnxruntime as ort
    options = ort.SessionOptions()
    options.intra_op_num_threads = 2
    options.inter_op_num_threads = 1
    options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
    options.enable_cpu_mem_arena = False
    session = ort.InferenceSession(str(path), options, providers=["CPUExecutionProvider"])
    if session.get_inputs()[0].shape != [1, 3, 768, 768]:
        raise ValueError("Unexpected pose input shape")
    input_name = session.get_inputs()[0].name
    distance_maps = [cv2.distanceTransform(1 - mask, cv2.DIST_L2, 3) for mask in masks]
    by_id = {tooth["instance_id"]: tooth for tooth in teeth}
    output_dir.joinpath(raw_folder).mkdir(parents=True)
    records = []
    height, width = rgb.shape[:2]
    for index, tooth in enumerate(teeth):
        if skip_complete and tooth["surfaces"]:
            continue
        _check_cancelled(cancelled)
        if progress:
            progress({"stage": "keypoints", "current": index, "total": len(teeth),
                      "message": f"{'旋转复查' if rotation else '识别'}牙齿 {index + 1}/{len(teeth)} 的三点候选"})
        crop_box = plan_roi(tooth["bbox_xyxy"], (width, height), margin=roi_margin)
        x1, y1, x2, y2 = crop_box
        crop = rgb[y1:y2, x1:x2]
        stem = tooth["instance_id"]
        if rotation == 180:
            crop = np.ascontiguousarray(crop[::-1, ::-1])
            view_to_crop = np.array([[-1, 0, x2-x1-1], [0, -1, y2-y1-1], [0, 0, 1]], dtype=np.float64)
        elif rotation == 0:
            view_to_crop = np.eye(3)
        else:
            raise ValueError("Only exact identity and 180-degree views are supported")
        crop_ref = f"{raw_folder}/{stem}_crop.png"
        Image.fromarray(crop).save(output_dir / crop_ref)
        tensor, transform = letterbox_rgb(crop)
        transform["crop_to_image"] = [[1, 0, x1], [0, 1, y1], [0, 0, 1]]
        transform["view_to_crop"] = view_to_crop.tolist()
        ratio = transform["ratio"]
        left, top = transform["padding_left_top"]
        network_to_view = np.array([[1/ratio, 0, -left/ratio], [0, 1/ratio, -top/ratio], [0, 0, 1]])
        transform["network_to_image"] = (np.array(transform["crop_to_image"]) @ view_to_crop @ network_to_view).tolist()
        start = time.perf_counter()
        output, = session.run(None, {input_name: tensor})
        elapsed = time.perf_counter() - start
        raw_ref = f"{raw_folder}/{stem}.npz"
        np.savez_compressed(output_dir / raw_ref, output=output)
        surfaces = decode_pose(output, transform, crop_box, (width, height))
        for surface_index, surface in enumerate(surfaces):
            view_id = raw_folder.replace("/", "_")
            surface["surface_id"] = f"{view_id}_{stem}_surface_{surface_index:03}"
            surface["source_crop_instance_id"] = stem
            surface["view_rotation_degrees"] = rotation
            surface["raw_output_ref"] = raw_ref
            if surface["accepted"]:
                assigned, association = surface_to_tooth(surface, teeth, distance_maps)
                surface["association"] = association
                surface["assigned_instance_id"] = assigned
                if assigned is None:
                    surface["accepted"] = False
                    surface["rejection_reason"] = "unassigned_tooth"
                else:
                    # Context ROIs include adjacent teeth. A confident surface belongs
                    # to its segmented instance, even when predicted in a neighbour's ROI.
                    surface["from_neighbour_context"] = assigned != stem
                    selected = merge_surface_candidate(by_id[assigned], surface)
                    surface["selected_at_this_stage"] = selected
        tooth["roi"] = {"bbox_xyxy": list(crop_box), "crop_ref": crop_ref, "transform": transform,
                         "orientation": f"rotation_{rotation}", "context_margin_fraction": list(roi_margin)}
        tooth.setdefault("roi_views", []).append(tooth["roi"])
        records.append({"instance_id": stem, "raw_ref": raw_ref, "forward_seconds": elapsed,
                        "view_rotation_degrees": rotation, "transform": transform,
                        "max_object_score": float(output[0, 4].max()), "surfaces": surfaces})
    del session, distance_maps
    gc.collect()
    _json(output_dir / raw_folder / "decoded.json", records)
    return {"onnxruntime": ort.__version__, "provider": "CPUExecutionProvider",
            "forward_seconds": sum(record["forward_seconds"] for record in records),
            "surface_count": sum(len(tooth["surfaces"]) for tooth in teeth),
            "teeth_with_surfaces": sum(bool(tooth["surfaces"]) for tooth in teeth),
            "forward_count": len(records), "decoded_ref": f"{raw_folder}/decoded.json"}


def _overlay(rgb, teeth, output_dir):
    image = Image.fromarray(rgb)
    draw = ImageDraw.Draw(image)
    colors = {"cej": "yellow", "bone_level": "cyan", "apex": "magenta"}
    for tooth in teeth:
        for contour in tooth["contours"]:
            vertices = [tuple(p) for p in contour]
            draw.line(vertices + vertices[:1], fill="lime", width=2)
        x, y = tooth["bbox_xyxy"][:2]
        draw.text((x, y), str(tooth["fdi"]), fill="lime")
        for surface in tooth["surfaces"]:
            for kind, point in surface["points"].items():
                px, py = point["xy"]
                draw.ellipse((px-4, py-4, px+4, py+4), fill=colors[kind])
    image.save(output_dir / "overlay.png")


def analyze_image(image_path, model_dir, output_dir, progress=None, cancelled=None, mode="full"):
    """Run real segmentation → ROI pose → coordinate restoration → JSON.

    ``output_dir`` must not already exist. Callbacks are optional; progress receives
    JSON-serializable dictionaries and cancelled returns bool. All returned point
    coordinates refer to the EXIF-corrected image, also saved as canonical.png/tiff.
    No candidates is a valid completed result and is explicitly counted.
    ``segmentation`` never verifies, loads or calls a keypoint model.
    """
    if mode not in {"full", "segmentation"}:
        raise ValueError("mode must be full or segmentation")
    start = time.perf_counter()
    output_dir = Path(output_dir)
    if output_dir.exists():
        raise FileExistsError("运行目录已存在，拒绝覆盖原始预测")
    _check_cancelled(cancelled)
    if progress:
        progress({"stage": "loading", "current": 0, "total": 1,
                  "message": "校验分割模型" if mode == "segmentation" else "校验两个已训练模型"})
    seg_path = verified_model_path(model_dir, SEGMENTATION)
    pose_path = verified_model_path(model_dir, POSE) if mode == "full" else None
    canonical = read_image(image_path)
    rgb = np.asarray(canonical.rgb8())
    output_dir.mkdir(parents=True, exist_ok=False)
    canonical_ref = "canonical" + canonical.canonical_extension
    output_dir.joinpath(canonical_ref).write_bytes(canonical.canonical_bytes)
    result = {
        "schema_version": "panodental.community-inference.v1", "run_id": str(uuid.uuid4()),
        "created_at_utc": datetime.now(timezone.utc).isoformat(), "status": "running", "mode": mode,
        "image": {"width": canonical.record.width, "height": canonical.record.height,
                  "source_name": Path(image_path).name, "sha256": canonical.record.original_sha256,
                  "canonical_sha256": canonical.record.canonical_sha256, "canonical_ref": canonical_ref,
                  "coordinate_space": "canonical_image_pixel_centers",
                  "original_to_canonical": canonical.record.original_to_canonical,
                  "canonical_to_original": canonical.record.canonical_to_original},
        "models": {"segmentation": SEGMENTATION, "keypoints": POSE if mode == "full" else None},
        "device": "cpu", "threads": 2, "training_steps": 0,
        "domain_validation": "panoramic_unvalidated", "accuracy": "not_evaluated",
        "preprocessing": {"segmentation": "RGB8 LAB-L CLAHE(2,8x8), /255, min800 max1333",
                          "keypoints": ("unpainted RGB ROI, /255, 768 letterbox; margin(.75,.15) identity then 180 for missing; margin(1.25,.15) identity only for still-missing teeth" if mode == "full" else None),
                          "pose_thresholds": {"object": .25, "nms_iou": .5, "each_keypoint": .30} if mode == "full" else None},
        "teeth": [], "warnings": ["所有自动结果均为待人工复核候选。"],
    }
    try:
        _json(output_dir / "run.json", result)
        _check_cancelled(cancelled)
        if progress:
            progress({"stage": "segmentation", "current": 0, "total": 1, "message": "正在自动分割全景片"})
        teeth, masks, segmentation = _segment(rgb, seg_path, output_dir, cancelled)
        result["teeth"], result["segmentation"] = teeth, segmentation
        _json(output_dir / "run.json", result)
        _check_cancelled(cancelled)
        if mode == "full":
            identity = _pose(rgb, teeth, masks, pose_path, output_dir, progress, cancelled,
                             roi_margin=(.75, .15), raw_folder="raw_pose/identity")
            retry = _pose(rgb, teeth, masks, pose_path, output_dir, progress, cancelled,
                          roi_margin=(.75, .15), rotation=180, skip_complete=True,
                          raw_folder="raw_pose/rotation_180")
            extra = _pose(rgb, teeth, masks, pose_path, output_dir, progress, cancelled,
                          roi_margin=(1.25, .15), skip_complete=True,
                          raw_folder="raw_pose/extra_context")
            views = {"identity": identity, "retry_180": retry, "extra_context": extra}
            combined_records = [record for view in views.values()
                                for record in json.loads((output_dir / view["decoded_ref"]).read_text(encoding="utf-8"))]
            _json(output_dir / "raw_pose" / "decoded.json", combined_records)
            result["keypoints"] = {**extra, "status": "completed",
                                   "forward_seconds": sum(v["forward_seconds"] for v in views.values()),
                                   "forward_count": sum(v["forward_count"] for v in views.values()),
                                   "decoded_ref": "raw_pose/decoded.json", "views": views,
                                   "retained_surface_ids": [s["surface_id"] for t in teeth for s in t["surfaces"]],
                                   "policy": "identity_then_180_then_wider_context_only_for_missing_teeth_max_3_views",
                                   "association_policy": "assign_to_segmented_tooth_across_context_rois_deduplicate_model_triplets"}
            result["boundary_constraint"] = project_teeth(teeth)
            result["warnings"].append("三点已按要求贴到第一次分割轮廓；几何贴线不代表解剖位置已验证。")
        else:
            result["keypoints"] = {"status": "not_requested", "surface_count": 0, "teeth_with_surfaces": 0,
                                   "forward_count": 0, "forward_seconds": 0., "views": {}}
        del masks
        _check_cancelled(cancelled)
        result["status"] = "completed"
        result["elapsed_seconds"] = time.perf_counter() - start
        result["peak_worker_working_set_gib"] = _peak_working_set()
        if not teeth:
            result["warnings"].append("未检出牙齿，请检查输入并人工标注。")
        elif mode == "full" and result["keypoints"]["teeth_with_surfaces"] < len(teeth):
            result["warnings"].append("部分牙齿未检出完整三点牙面，请人工补标。")
        _overlay(rgb, teeth, output_dir)
        result["overlay_ref"] = "overlay.png"
        _json(output_dir / "result.json", result)
        _json(output_dir / "run.json", result)
        if progress:
            progress({"stage": "completed", "current": len(teeth), "total": len(teeth),
                      "message": (f"分割 {len(teeth)} 颗牙" if mode == "segmentation" else
                                  f"分割 {len(teeth)} 颗牙，获得 {result['keypoints']['surface_count']} 组三点候选")})
        return result
    except BaseException as exc:
        result["status"] = "cancelled" if isinstance(exc, InferenceCancelled) else "failed"
        result["error"] = {"type": type(exc).__name__, "message": str(exc)}
        result["elapsed_seconds"] = time.perf_counter() - start
        _json(output_dir / "run.json", result)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", type=Path, required=True)
    parser.add_argument("--models", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--mode", choices=("full", "segmentation"), default="full")
    args = parser.parse_args()
    def progress(record):
        print(json.dumps({"event": "progress", **record}, ensure_ascii=False), flush=True)
    result = analyze_image(args.image, args.models, args.output, progress=progress, mode=args.mode)
    print(json.dumps({"event": "result", "path": str(args.output / "result.json"),
                      "teeth": len(result["teeth"]), **result["keypoints"]}, ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
