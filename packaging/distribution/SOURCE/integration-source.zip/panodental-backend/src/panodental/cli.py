"""Shared audit, desktop, project and export commands."""

import argparse
from importlib import metadata
import json
import platform
from pathlib import Path

from .audit import main as audit_main


def main(argv=None):
    parser = argparse.ArgumentParser(prog="panodental")
    sub = parser.add_subparsers(dest="command", required=True)
    doctor = sub.add_parser("doctor", help="Report actual host and missing model state")
    doctor.add_argument("--json", action="store_true")
    doctor.add_argument("--cpu-check", action="store_true")
    gui = sub.add_parser("gui", help="Open the native annotation workbench")
    gui.add_argument("--input", type=Path)
    gui.add_argument("--probe-report", type=Path)
    gui.add_argument("--screenshot", type=Path)
    gui.add_argument("--exit-after-probe", action="store_true")
    for name in ("export", "crop", "validate-project"):
        command = sub.add_parser(name)
        command.add_argument("--project", type=Path, required=True)
        if name != "validate-project":
            command.add_argument("--output", type=Path, required=True)
    infer = sub.add_parser("infer")
    infer.add_argument("--input", type=Path, required=True)
    infer.add_argument("--output", type=Path, required=True)
    infer.add_argument("--device", choices=["cpu"], default="cpu")
    audit = sub.add_parser("audit", help="Read user archive metadata without executing it")
    audit.add_argument("--workspace", type=Path, required=True)
    audit.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    if args.command == "gui":
        from .ui.window import run_gui
        return run_gui(args.input, args.probe_report, args.screenshot, args.exit_after_probe)
    if args.command == "infer":
        from .worker import dispatch
        print(json.dumps(dispatch({"request_id": "cli", "command": "run_image"}), ensure_ascii=False))
        return 2
    if args.command in {"export", "crop", "validate-project"}:
        from .project import Document
        from .crops import export_crops
        try:
            document = Document.open(args.project)
            if args.command == "validate-project":
                result = {"valid": True, "revision": document.annotation.revision}
            else:
                output = document.export(args.output) if args.command == "export" else export_crops(document, args.output)
                result = {"output": str(output)}
            print(json.dumps(result, ensure_ascii=False))
            return 0
        except Exception as error:
            print(json.dumps({"error": str(error)}, ensure_ascii=False))
            return 5
    if args.command == "audit":
        params = ["--workspace", str(args.workspace)]
        if args.output:
            params.extend(["--output", str(args.output)])
        return audit_main(params)
    versions = {}
    for package in ("numpy", "Pillow", "pydantic", "PySide6", "torch", "torchvision", "pyinstaller"):
        try:
            versions[package] = metadata.version(package)
        except metadata.PackageNotFoundError:
            versions[package] = None
    report = {
        "platform": platform.system(), "architecture": platform.machine(),
        "python": platform.python_version(), "dependencies": versions,
        "application_stage": "MANUAL_WORKBENCH", "delivery_target": "Windows x64",
        "segmentation": "NOT_CONFIGURED", "landmarks": "NOT_CONFIGURED",
        "accuracy": "NOT_EVALUATED", "gui": "manual_annotation_available",
    }
    if args.cpu_check:
        from .runtime import health
        report["runtime_health"] = health()
    print(json.dumps(report, ensure_ascii=False, indent=2))
    # Missing required models is a distinct non-success exit, even if diagnosis works.
    return 2
