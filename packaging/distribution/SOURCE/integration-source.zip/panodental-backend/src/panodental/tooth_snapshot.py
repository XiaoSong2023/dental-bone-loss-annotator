"""Validate existing UI teeth without creating or modifying segmentation results."""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path

import numpy as np


def _coordinates(value):
    array = np.asarray(value)
    if array.dtype.kind not in "iuf":
        raise ValueError("坐标必须为有限数值")
    return array.astype(np.float64)


def load_teeth_snapshot(path, image_record):
    """Return unchanged tooth geometry and private association-region rasters.

    Rectangle rasters for contourless teeth are association aids only. They are
    never exported as a segmentation mask, contour, or trained-model confidence.
    """
    import cv2
    cv2.setNumThreads(2)
    raw = Path(path).read_bytes()
    snapshot = json.loads(raw)
    if (not isinstance(snapshot, dict) or type(snapshot.get("schema_version")) is not int
            or snapshot.get("schema_version") != 1):
        raise ValueError("牙框快照 schema_version 必须为1")
    image = snapshot.get("image")
    expected = {"width": image_record.width, "height": image_record.height,
                "sha256": image_record.original_sha256}
    if (not isinstance(image, dict) or any(image.get(k) != v for k, v in expected.items())
            or type(image.get("width")) is not int or type(image.get("height")) is not int):
        raise ValueError("牙框快照与输入影像尺寸或SHA256不一致")
    rows = snapshot.get("teeth")
    if not isinstance(rows, list) or not rows:
        raise ValueError("三点识别需要至少一个现有牙框")
    width, height = image_record.width, image_record.height
    teeth, regions, ids = [], [], set()
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("牙框快照项目必须是对象")
        required = ("source_tooth_id", "instance_id", "fdi", "origin", "score", "bbox_xyxy", "contours")
        if any(key not in row for key in required):
            raise ValueError("牙框快照缺少必需字段")
        ident = row.get("source_tooth_id")
        if not isinstance(ident, str) or not ident or row.get("instance_id") != ident or ident in ids:
            raise ValueError("source_tooth_id必须唯一且与instance_id一致")
        ids.add(ident)
        if row.get("origin") not in ("model", "manual"):
            raise ValueError("牙框origin必须为model或manual")
        fdi = row.get("fdi")
        if fdi is not None and (not isinstance(fdi, int) or isinstance(fdi, bool)):
            raise ValueError("牙位fdi必须为整数或null")
        score = row.get("score")
        if score is not None and (isinstance(score, bool) or not isinstance(score, (int, float))
                                  or not np.isfinite(score) or not 0 <= score <= 1):
            raise ValueError("现有分割score必须为0到1之间数值或null")
        box = _coordinates(row.get("bbox_xyxy"))
        if (box.shape != (4,) or not np.isfinite(box).all()
                or not 0 <= box[0] < box[2] <= width or not 0 <= box[1] < box[3] <= height):
            raise ValueError("现有牙框bbox_xyxy无效或超出原图")
        contours = row.get("contours")
        if not isinstance(contours, list):
            raise ValueError("牙齿contours必须为数组，可为空")
        region = np.zeros((height, width), dtype=np.uint8)
        for contour in contours:
            vertices = _coordinates(contour)
            if (vertices.ndim != 2 or vertices.shape[1:] != (2,) or len(vertices) < 3
                    or not np.isfinite(vertices).all() or np.any(vertices < 0)
                    or np.any(vertices[:, 0] > width-1) or np.any(vertices[:, 1] > height-1)):
                raise ValueError("现有分割轮廓无效或超出原图")
            if cv2.contourArea(vertices.astype(np.float32)) <= 0:
                raise ValueError("现有分割轮廓没有有效面积")
            cv2.fillPoly(region, [np.rint(vertices).astype(np.int32)], 1)
        method = "existing_segmentation_contour"
        if not contours:
            x1, y1 = np.floor(box[:2]).astype(int)
            x2, y2 = np.ceil(box[2:]).astype(int)
            region[y1:y2, x1:x2] = 1
            method = "current_roi_rectangle_internal_only"
        if not region.any():
            raise ValueError("现有牙齿区域无法用于三点归属")
        tooth = {key: copy.deepcopy(row[key]) for key in required}
        tooth.update(surfaces=[], association_region=method, review_status="unreviewed")
        teeth.append(tooth)
        regions.append(region)
    return teeth, regions, {
        "schema_version": 1, "sha256": hashlib.sha256(raw).hexdigest(),
        "tooth_count": len(teeth), "raw_ref": "input_teeth.json",
        "geometry_policy": "existing_snapshot_unchanged_no_segmentation",
        "contour_rasterization": "round_to_nearest_integer_then_fillPoly_association_only",
    }, raw
