"""Pixel-center transforms, separate from any Qt viewport or model internals."""

from dataclasses import dataclass
import math
import numpy as np


@dataclass(frozen=True)
class Transform:
    matrix: np.ndarray

    def __post_init__(self):
        m = np.array(self.matrix, dtype=np.float64, copy=True)
        if m.shape != (3, 3) or not np.isfinite(m).all() or abs(np.linalg.det(m)) < 1e-12:
            raise ValueError("无效坐标变换")
        m.setflags(write=False)
        object.__setattr__(self, "matrix", m)

    def apply(self, points):
        p = np.asarray(points, dtype=np.float64).reshape(-1, 2)
        q = np.column_stack([p, np.ones(len(p))]) @ self.matrix.T
        return q[:, :2] / q[:, 2:]

    def inverse(self):
        return Transform(np.linalg.inv(self.matrix))

    @classmethod
    def crop_resize(cls, box, output_size, padding=(0, 0)):
        x1, y1, x2, y2 = box
        if x2 <= x1 or y2 <= y1 or min(output_size) <= 0:
            raise ValueError("无效裁剪尺寸")
        sx, sy = output_size[0] / (x2 - x1), output_size[1] / (y2 - y1)
        # This helper declares half-pixel resize. Do not apply again to framework-restored results.
        return cls(np.array([[sx, 0, (-x1 + .5) * sx - .5 + padding[0]],
                             [0, sy, (-y1 + .5) * sy - .5 + padding[1]], [0, 0, 1]]))


def exif_transform(orientation, width, height):
    matrices = {
        1: [[1, 0, 0], [0, 1, 0], [0, 0, 1]],
        2: [[-1, 0, width-1], [0, 1, 0], [0, 0, 1]],
        3: [[-1, 0, width-1], [0, -1, height-1], [0, 0, 1]],
        4: [[1, 0, 0], [0, -1, height-1], [0, 0, 1]],
        5: [[0, 1, 0], [1, 0, 0], [0, 0, 1]],
        6: [[0, -1, height-1], [1, 0, 0], [0, 0, 1]],
        7: [[0, -1, height-1], [-1, 0, width-1], [0, 0, 1]],
        8: [[0, 1, 0], [-1, 0, width-1], [0, 0, 1]],
    }
    if orientation not in matrices:
        raise ValueError("不支持的 EXIF 方向")
    size = (height, width) if orientation >= 5 else (width, height)
    return Transform(np.array(matrices[orientation])), size


def plan_roi(box, image_size, margin=(.25, .15)):
    x1, y1, x2, y2 = box
    mx, my = (x2-x1)*margin[0], (y2-y1)*margin[1]
    crop = (max(0, math.floor(x1-mx)), max(0, math.floor(y1-my)),
            min(image_size[0], math.ceil(x2+mx)), min(image_size[1], math.ceil(y2+my)))
    if crop[0] >= crop[2] or crop[1] >= crop[3]:
        raise ValueError("裁剪不与图像相交")
    return crop
