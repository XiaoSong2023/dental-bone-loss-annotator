"""Exact projection onto the first-pass segmentation polyline, without anatomy guesses."""
from __future__ import annotations

import copy
import hashlib
import json

import numpy as np


def contour_sha256(contours):
    return hashlib.sha256(json.dumps(contours, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def nearest_contour_point(xy, contours):
    """Return the global closest point on all closed contour segments.

    Works in float64 image coordinates and includes the final-to-first segment.
    This is a geometric constraint only: it cannot locate an anatomical landmark.
    """
    point = np.asarray(xy, dtype=np.float64)
    if point.shape != (2,) or not np.isfinite(point).all():
        raise ValueError("Projection requires a finite 2D point")
    best = None
    for contour_index, contour in enumerate(contours):
        vertices = np.asarray(contour, dtype=np.float64)
        if vertices.ndim != 2 or vertices.shape[1:] != (2,) or len(vertices) < 2:
            continue
        if not np.isfinite(vertices).all():
            raise ValueError("Non-finite contour")
        starts, ends = vertices, np.roll(vertices, -1, axis=0)
        vectors = ends - starts
        lengths_squared = np.einsum("ij,ij->i", vectors, vectors)
        numerators = np.einsum("ij,ij->i", point - starts, vectors)
        fraction = np.divide(numerators, lengths_squared, out=np.zeros_like(numerators),
                             where=lengths_squared > 0)
        fraction = np.clip(fraction, 0., 1.)
        projections = starts + fraction[:, None] * vectors
        distance_squared = np.sum((projections - point) ** 2, axis=1)
        segment_index = int(np.argmin(distance_squared))
        distance = float(distance_squared[segment_index])
        if best is None or distance < best[0]:
            best = (distance, {"projected_xy": projections[segment_index].tolist(),
                              "distance_px": float(np.sqrt(distance)),
                              "contour_index": contour_index, "segment_index": segment_index,
                              "segment_t": float(fraction[segment_index])})
    if best is None:
        raise ValueError("No valid contour segments for boundary projection")
    return best[1]


def project_surface(surface, contours):
    """Copy a trained-model surface and constrain each supplied point to the boundary.

    Never creates a missing point, changes model scores, or overwrites model raw_xy.
    """
    projected = copy.deepcopy(surface)
    boundary_hash = contour_sha256(contours)
    for point in projected.get("points", {}).values():
        if point is None:
            continue
        raw = point.get("raw_xy", point["xy"])
        projection = nearest_contour_point(raw, contours)
        point["raw_xy"] = list(raw)
        point["pre_projection_xy"] = list(point["xy"])
        point["projected_xy"] = list(projection["projected_xy"])
        point["xy"] = list(projection["projected_xy"])
        point["boundary_projection"] = {
            "method": "nearest_closed_polyline_segment_float64",
            "reference": "first_pass_segmentation_contours",
            "contour_sha256": boundary_hash,
            **{key: value for key, value in projection.items() if key != "projected_xy"},
        }
    projected["postprocessing"] = "geometric_boundary_projection_not_anatomical_revalidation"
    return projected


def project_teeth(teeth):
    distances, residuals = [], []
    for tooth in teeth:
        tooth["contour_sha256"] = contour_sha256(tooth["contours"])
        tooth["surfaces"] = [project_surface(surface, tooth["contours"])
                              for surface in tooth.get("surfaces", [])]
        for surface in tooth["surfaces"]:
            for point in surface["points"].values():
                if point is None:
                    continue
                distances.append(point["boundary_projection"]["distance_px"])
                residuals.append(nearest_contour_point(point["xy"], tooth["contours"])["distance_px"])
    return {"method": "nearest_closed_polyline_segment_float64",
            "reference": "first_pass_segmentation_contours", "projected_point_count": len(distances),
            "maximum_projection_distance_px": max(distances, default=0.),
            "mean_projection_distance_px": float(np.mean(distances)) if distances else 0.,
            "maximum_boundary_residual_px": max(residuals, default=0.),
            "model_scores_unchanged": True, "anatomical_accuracy_claimed": False}
