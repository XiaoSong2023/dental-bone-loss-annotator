"""Download explicit research candidates; verify immutable revision, size and SHA-256.

This does not load pickle, start training, or configure the application models.
"""
import argparse
import hashlib
import json
from pathlib import Path
from urllib.request import Request, urlopen


CANDIDATES = [
    ("chocodo/teeth-segmentation-odontoai", "4867533fb8e8ccd115c10c533a238e4288757165", "best.pth",
     177303086, "37bb200f5aa6620fc58fe549d8babd0080b6d2b661d1e33ec452ea3f329f7012", "mit"),
    ("rummanadib023/denpar-bone-loss-v2", "d254abd6df9ab41c0367b99457334d7f1ea69895", "surf_pose.onnx",
     106101619, "60d14e5b6560cbf834ffd0a6aff0c0558390224bbe1902199931479bfb89ad98", None),
    ("rummanadib023/denpar-bone-loss-v2", "d254abd6df9ab41c0367b99457334d7f1ea69895", "surf_pose.pt",
     53187840, "6a769e771b66f6f89fa1c341897e5be1b05876b05af9daa235ae37c084288a46", None),
]


def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    records = []
    for repo, revision, filename, size, digest, license_name in CANDIDATES:
        folder = args.output / repo.replace("/", "--")
        folder.mkdir(parents=True, exist_ok=True)
        target = folder / filename
        url = f"https://huggingface.co/{repo}/resolve/{revision}/{filename}?download=true"
        if not (target.exists() and target.stat().st_size == size and sha256(target) == digest):
            temporary = target.with_suffix(target.suffix + ".download")
            received = 0
            last_report = 0
            h = hashlib.sha256()
            request = Request(url, headers={"User-Agent": "PanoDental-asset-audit"})
            with urlopen(request, timeout=45) as response, temporary.open("wb") as stream:
                for block in iter(lambda: response.read(1024 * 1024), b""):
                    received += len(block)
                    if received > size:
                        raise ValueError(f"Unexpected size for {repo}/{filename}")
                    h.update(block)
                    stream.write(block)
                    if received - last_report >= 25 * 1024 * 1024:
                        print(json.dumps({"file": filename, "downloaded": received, "total": size}), flush=True)
                        last_report = received
            if received != size or h.hexdigest() != digest:
                raise ValueError(f"Integrity mismatch for {repo}/{filename}; file not activated")
            temporary.replace(target)
        record = {"repo": repo, "revision": revision, "file": filename, "bytes": size,
                  "sha256": digest, "license_from_model_card": license_name, "download_url": url,
                  "integrity": "VERIFIED", "application_configured": False,
                  "accuracy": "NOT_EVALUATED", "redistribution": "NOT_REVIEWED"}
        records.append(record)
        print(json.dumps(record), flush=True)
        (args.output / "manifest.local.json").write_text(
            json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
