"""Bounded CPU probe on real tooth crops selected from supplied ground-truth polygons.

This is NOT an automatic segmentation or application pipeline test. Crop selection uses
dataset annotations; all point predictions, when present, come from the verified ONNX.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

from training_preflight import memory_status


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def infer(args):
    import zipfile
    import cv2
    import numpy as np
    import onnxruntime as ort
    from PIL import Image, ImageDraw

    expected = "60d14e5b6560cbf834ffd0a6aff0c0558390224bbe1902199931479bfb89ad98"
    with args.model.open("rb") as stream:
        if hashlib.file_digest(stream, "sha256").hexdigest() != expected:
            raise ValueError("Unverified ONNX weights")
    image = Image.open(args.image).convert("RGB")
    width, height = image.size
    with zipfile.ZipFile(args.dataset) as archive:
        label_name, = [name for name in archive.namelist()
                       if "/labels/" in name and Path(name).stem == args.image.stem]
        rows = archive.read(label_name).decode("utf-8").splitlines()
    boxes = []
    for row in rows:
        if not row.strip():
            continue
        values = [float(v) for v in row.split()]
        points = np.array(values[1:]).reshape(-1, 2) * [width, height]
        lo, hi = points.min(0), points.max(0)
        boxes.append((float(np.prod(hi-lo)), int(values[0]), lo, hi))
    boxes.sort(key=lambda b: b[0], reverse=True)
    if len(boxes) < 3:
        raise ValueError("Expected multiple annotated real teeth")
    options = ort.SessionOptions()
    options.intra_op_num_threads = 2
    options.inter_op_num_threads = 1
    options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
    options.enable_cpu_mem_arena = False
    session = ort.InferenceSession(str(args.model), options, providers=["CPUExecutionProvider"])
    if session.get_inputs()[0].shape != [1, 3, 768, 768]:
        raise ValueError("Unexpected model input")
    results = []
    for index, (_, class_id, lo, hi) in enumerate([boxes[0], boxes[len(boxes)//2], boxes[-1]]):
        margin = (hi-lo) * [.25, .15]
        x1, y1 = np.maximum(0, np.floor(lo-margin)).astype(int)
        x2, y2 = np.minimum([width, height], np.ceil(hi+margin)).astype(int)
        crop = image.crop((int(x1), int(y1), int(x2), int(y2)))
        crop.save(args.output / f"gt_roi_{index}.png")
        rgb = np.asarray(crop)
        ratio = min(768 / crop.width, 768 / crop.height)
        resized = (round(crop.width * ratio), round(crop.height * ratio))
        dw, dh = (768-resized[0])/2, (768-resized[1])/2
        left, top = round(dw-.1), round(dh-.1)
        network_image = cv2.resize(rgb, resized, interpolation=cv2.INTER_LINEAR)
        network_image = cv2.copyMakeBorder(network_image, top, round(dh+.1), left, round(dw+.1),
                                          cv2.BORDER_CONSTANT, value=(114, 114, 114))
        tensor = np.ascontiguousarray(network_image.transpose(2, 0, 1)[None], dtype=np.float32) / 255
        start = time.perf_counter()
        output, = session.run(None, {session.get_inputs()[0].name: tensor})
        elapsed = time.perf_counter() - start
        if output.shape != (1, 14, 12096) or not np.isfinite(output).all():
            raise ValueError("Invalid pose output")
        np.savez_compressed(args.output / f"raw_pose_{index}.npz", output=output)
        raw = output[0].T
        candidates = raw[raw[:, 4] >= .25]
        retained = []
        if len(candidates):
            xywh = candidates[:, :4].copy()
            xywh[:, :2] -= xywh[:, 2:]/2
            selected = np.asarray(cv2.dnn.NMSBoxes(xywh.tolist(), candidates[:, 4].tolist(), .25, .5)).reshape(-1)
            for selected_index in selected:
                row = candidates[int(selected_index)]
                keypoints = row[5:].reshape(3, 3)
                if np.any(keypoints[:, 2] < .30):
                    continue
                crop_xy = (keypoints[:, :2] - [left, top]) / ratio
                original_xy = crop_xy + [x1, y1]
                retained.append({"object_score": float(row[4]), "side": "unknown",
                                 "raw_network_keypoints": keypoints.tolist(), "crop_xy": crop_xy.tolist(),
                                 "original_xy": original_xy.tolist(),
                                 "coordinate_rule": "Ultralytics continuous coordinates: (network-pad)/ratio+crop_origin",
                                 "point_order_from_model_card": ["cej", "bone_level_intersection", "apex"]})
        overlay = crop.copy()
        draw = ImageDraw.Draw(overlay)
        for surface in retained:
            for label, color, (x, y) in zip(["CEJ", "BL", "AP"], ["yellow", "cyan", "magenta"], surface["crop_xy"]):
                draw.ellipse((x-3, y-3, x+3, y+3), fill=color)
                draw.text((x+4, y+2), label, fill=color)
        overlay.save(args.output / f"pose_overlay_{index}.png")
        results.append({"crop_index": index, "dataset_class_id": class_id,
                        "crop_source": "GROUND_TRUTH_POLYGON_BOUNDING_BOX_NOT_AUTOMATIC_SEGMENTATION",
                        "crop_box_xyxy": [int(x1), int(y1), int(x2), int(y2)],
                        "network_input": [1, 3, 768, 768], "resize_ratio": ratio,
                        "letterbox_padding_left_top": [left, top], "forward_seconds": elapsed,
                        "max_object_score": float(raw[:, 4].max()), "surfaces": retained})
        print(json.dumps({"crop": index, "surfaces": len(retained), "forward_seconds": elapsed}), flush=True)
    write_json(args.output / "pose_probe.local.json", {
        "model_sha256": expected, "providers": session.get_providers(), "threads": 2,
        "image_sha256": hashlib.sha256(args.image.read_bytes()).hexdigest(), "image_size": [width, height],
        "crop_selection": "supplied dataset ground truth; not segmentation model outputs",
        "automatic_segmentation": "NOT_RUN", "application_pipeline": "NOT_RUN",
        "accuracy": "NOT_EVALUATED", "native_pytorch_comparison": "NOT_RUN", "results": results})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("model", "image", "dataset", "output"):
        parser.add_argument("--"+name, type=Path, required=True)
    parser.add_argument("--child", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.child:
        infer(args)
        return 0
    args.output.mkdir(parents=True, exist_ok=False)
    before = memory_status()
    summary = {"before": before, "training_steps": 0, "minimum_available_ram_gib_during_probe": .5,
               "timeout_seconds": 120, "automatic_segmentation": "NOT_RUN"}
    if before["available_physical_gib"] < 1.0:
        summary["status"] = "STOPPED_LOW_AVAILABLE_MEMORY_BEFORE_INFERENCE"
        write_json(args.output / "resource_monitor.local.json", summary)
        print(json.dumps(summary), flush=True)
        return 2
    start = time.monotonic()
    minimum_free = before["available_physical_gib"]
    with (args.output / "probe.log").open("w", encoding="utf-8") as log:
        process = subprocess.Popen([sys.executable, __file__, *sys.argv[1:], "--child"],
                                   stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
        stopped = None
        while process.poll() is None:
            free = memory_status()["available_physical_gib"]
            minimum_free = min(minimum_free, free)
            if free < .5 or time.monotonic() - start > 120:
                stopped = "STOPPED_LOW_AVAILABLE_MEMORY" if free < .5 else "STOPPED_TIMEOUT"
                process.terminate()
                process.wait(timeout=10)
                break
            time.sleep(.25)
    summary.update({"status": stopped or ("PASS_EXECUTION_ONLY" if process.returncode == 0 else "FAILED"),
                    "exit_code": process.returncode, "elapsed_seconds": time.monotonic()-start,
                    "minimum_observed_available_gib": minimum_free, "after": memory_status()})
    write_json(args.output / "resource_monitor.local.json", summary)
    print(json.dumps(summary), flush=True)
    return 0 if summary["status"] == "PASS_EXECUTION_ONLY" else 2


if __name__ == "__main__":
    raise SystemExit(main())
