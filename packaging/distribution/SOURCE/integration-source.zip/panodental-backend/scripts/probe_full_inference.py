"""Bounded real automatic pipeline probe; never uses annotations or training data labels."""
import argparse
import ctypes
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from training_preflight import memory_status


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", type=Path, required=True)
    parser.add_argument("--models", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--timeout", type=int, default=360)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    before = memory_status()
    if before["available_physical_gib"] < 1.0:
        raise RuntimeError("Less than 1 GiB available; inference probe not admitted")
    report = {"before": before, "training_steps": 0, "uses_ground_truth": False}
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "src")
    start = time.monotonic()
    minimum_free = before["available_physical_gib"]
    peak_working_set = 0
    class ProcessMemory(ctypes.Structure):
        _fields_ = [("cb", ctypes.c_ulong), ("page_faults", ctypes.c_ulong)] + [
            (name, ctypes.c_size_t) for name in ("peak_working_set", "working_set", "peak_paged_pool",
            "paged_pool", "peak_nonpaged_pool", "nonpaged_pool", "pagefile_usage", "peak_pagefile_usage")]
    log_path = args.output.with_suffix(".log")
    with log_path.open("w", encoding="utf-8") as log:
        process = subprocess.Popen([sys.executable, "-m", "panodental.inference", "--image", str(args.image),
                                    "--models", str(args.models), "--output", str(args.output)],
                                   env=env, stdout=log, stderr=subprocess.STDOUT,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        stopped = None
        while process.poll() is None:
            memory = memory_status()
            free = memory["available_physical_gib"]
            minimum_free = min(minimum_free, free)
            state = ProcessMemory()
            state.cb = ctypes.sizeof(state)
            if ctypes.windll.psapi.GetProcessMemoryInfo(ctypes.c_void_p(int(process._handle)),
                                                        ctypes.byref(state), state.cb):
                peak_working_set = max(peak_working_set, state.peak_working_set)
            if free < .35 or time.monotonic() - start > args.timeout:
                stopped = "stopped_low_memory" if free < .35 else "stopped_timeout"
                process.terminate()
                process.wait(timeout=10)
                break
            time.sleep(.25)
    actual_worker_peak = None
    result_path = args.output / "result.json"
    if result_path.exists():
        actual_worker_peak = json.loads(result_path.read_text(encoding="utf-8")).get("peak_worker_working_set_gib")
    report.update(status=stopped or ("completed" if process.returncode == 0 else "failed"),
                  exit_code=process.returncode, elapsed_seconds=time.monotonic() - start,
                  minimum_available_gib=minimum_free, peak_launcher_working_set_gib=peak_working_set/2**30,
                  peak_worker_working_set_gib=actual_worker_peak,
                  after=memory_status())
    report_path = args.output.with_suffix(".resource.json")
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report), flush=True)
    return 0 if report["status"] == "completed" else 2


if __name__ == "__main__":
    raise SystemExit(main())
