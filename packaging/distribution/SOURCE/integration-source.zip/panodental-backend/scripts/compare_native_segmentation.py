"""Compare the adapter's saved predictions with an independent torchvision constructor.

Uses the verified state_dict, not COCO inference. The publisher's reviewed CLAHE
function is extracted from its source without importing or running its entry points.
"""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import time

import cv2
import numpy as np
import torch
from torchvision.models.detection import maskrcnn_resnet50_fpn
from torchvision.ops import FrozenBatchNorm2d

from panodental.imaging import read_image
from panodental.inference import SEGMENTATION, verified_model_path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--result", type=Path, required=True)
    parser.add_argument("--image", type=Path, required=True)
    parser.add_argument("--models", type=Path, required=True)
    parser.add_argument("--preprocessing-source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    saved = json.loads(args.result.read_text(encoding="utf-8"))
    image = read_image(args.image)
    if saved["image"]["sha256"] != image.record.original_sha256:
        raise ValueError("Comparison image differs")
    module = ast.parse(args.preprocessing_source.read_text(encoding="utf-8"))
    function, = [node for node in module.body if isinstance(node, ast.FunctionDef) and node.name == "enhance_contrast"]
    namespace = {"np": np, "cv2": cv2}
    exec(compile(ast.Module(body=[function], type_ignores=[]), str(args.preprocessing_source), "exec"), namespace)
    enhanced = namespace["enhance_contrast"](np.asarray(image.rgb8()), method="clahe")
    tensor = torch.from_numpy(np.ascontiguousarray(enhanced.transpose(2, 0, 1))).float() / 255
    torch.set_num_threads(2)
    cv2.setNumThreads(2)
    # The publisher calls this public factory with COCO weights, which selects FrozenBN,
    # then replaces the heads and overwrites every tensor. Here no COCO download is needed:
    # explicitly restore FrozenBN topology before strict audited state assignment.
    with torch.device("meta"):
        native = maskrcnn_resnet50_fpn(weights=None, weights_backbone=None, num_classes=53,
                                      box_nms_thresh=.5, box_score_thresh=.3, box_detections_per_img=60)
        def frozen_norm(module):
            for name, child in list(module.named_children()):
                if isinstance(child, torch.nn.BatchNorm2d):
                    setattr(module, name, FrozenBatchNorm2d(child.num_features, eps=0.))
                else:
                    frozen_norm(child)
        # torchvision's COCO legacy checkpoint loader sets FrozenBN epsilon to 0.
        # Check the adapter's backbone constructor default below through the comparison;
        # differing eps must be resolved explicitly rather than tolerated silently.
        frozen_norm(native)
    state = torch.load(verified_model_path(args.models, SEGMENTATION), map_location="cpu", weights_only=True, mmap=True)
    native.load_state_dict(state, strict=True, assign=True)
    native.eval()
    start = time.perf_counter()
    with torch.inference_mode():
        prediction = native([tensor])[0]
    elapsed = time.perf_counter() - start
    saved_raw = args.result.parent / "raw_segmentation"
    detection = np.load(saved_raw / "detections.npz")
    report = {"comparison": "independent torchvision factory + publisher CLAHE function",
              "image_sha256": saved["image"]["sha256"], "weights_sha256": SEGMENTATION["sha256"],
              "preprocessing_source_sha256": hashlib.sha256(args.preprocessing_source.read_bytes()).hexdigest(),
              "forward_seconds": elapsed, "torch": torch.__version__, "strict_state_dict": True,
              "native_detection_count": len(prediction["scores"]), "accuracy": "not_evaluated"}
    maxima = {}
    for key in ("boxes", "labels", "scores"):
        actual = prediction[key].numpy()
        expected = detection[key]
        if actual.shape != expected.shape:
            raise AssertionError(f"Native {key} shape differs: {actual.shape} vs {expected.shape}")
        maxima[key] = float(np.max(np.abs(actual - expected))) if actual.size else 0.
    maxima["mask_probability"] = 0.
    mask_binary_differences = 0
    for index in range(len(prediction["scores"])):
        expected = np.load(saved_raw / f"mask_probability_{index:03}.npz")["probability"]
        actual = prediction["masks"][index, 0].numpy()
        maxima["mask_probability"] = max(maxima["mask_probability"], float(np.max(np.abs(actual - expected))))
        mask_binary_differences += int(np.count_nonzero((actual > .5) != (expected > .5)))
    report["maximum_absolute_errors"] = maxima
    report["binary_mask_pixel_differences"] = mask_binary_differences
    report["status"] = "pass" if max(maxima.values()) < 1e-4 and mask_binary_differences == 0 else "failed"
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report), flush=True)
    return 0 if report["status"] == "pass" else 2


if __name__ == "__main__":
    raise SystemExit(main())
