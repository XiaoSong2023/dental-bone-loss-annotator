"""Audit cached real assignments, then a bounded extra-context pose experiment.

No ground-truth labels, training, threshold reduction or fabricated landmarks are used.
The original real run is read only; the experiment records its source and checksum.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import time

import numpy as np
from PIL import Image

from panodental.boundary import project_teeth
from panodental.inference import (POSE, SEGMENTATION, _json, _overlay, _peak_working_set,
                                  _pose, merge_surface_candidate, verified_model_path)


def counts(teeth):
    return {"segmented_teeth": len(teeth), "surface_count": sum(len(t["surfaces"]) for t in teeth),
            "teeth_with_surfaces": sum(bool(t["surfaces"]) for t in teeth),
            "fdI_with_surfaces": sorted(t["fdi"] for t in teeth if t["surfaces"])}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", required=True, type=Path)
    parser.add_argument("--models", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--assignment-only", action="store_true")
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    baseline_bytes = args.baseline.read_bytes()
    baseline = json.loads(baseline_bytes)
    if baseline["status"] != "completed" or baseline["models"]["segmentation"]["sha256"] != SEGMENTATION["sha256"]:
        raise ValueError("Expected audited, completed real segmentation baseline")
    args.output.mkdir(parents=True)
    source = args.baseline.parent
    image = Image.open(source / baseline["image"]["canonical_ref"]).convert("RGB")
    rgb = np.asarray(image)
    teeth = copy.deepcopy(baseline["teeth"])
    by_id = {tooth["instance_id"]: tooth for tooth in teeth}
    masks = [np.asarray(Image.open(source / tooth["mask_ref"]).convert("L")) > 0 for tooth in teeth]
    for tooth in teeth:
        tooth["surfaces"] = []
        tooth["surface_selection"] = []
    decoded = json.loads((source / baseline["keypoints"]["decoded_ref"]).read_text(encoding="utf-8"))
    reassignment = []
    for record in decoded:
        for index, surface in enumerate(record["surfaces"]):
            assigned = surface.get("assigned_instance_id")
            if assigned not in by_id or surface.get("rejection_reason") not in (None, "unassigned_or_neighbouring_tooth"):
                continue
            candidate = copy.deepcopy(surface)
            candidate["accepted"], candidate["rejection_reason"] = True, None
            candidate["surface_id"] = f"cached_{record['instance_id']}_{record.get('view_rotation_degrees', 0)}_{index}"
            candidate["raw_source_result"] = str(args.baseline.resolve())
            candidate["from_neighbour_context"] = assigned != record["instance_id"]
            merge_surface_candidate(by_id[assigned], candidate)
            if candidate["from_neighbour_context"]:
                reassignment.append({"source_fdi": by_id[record["instance_id"]]["fdi"],
                                     "assigned_fdi": by_id[assigned]["fdi"], "score": candidate["object_score"]})
    report = {"baseline_path": str(args.baseline.resolve()),
              "baseline_sha256": hashlib.sha256(baseline_bytes).hexdigest(),
              "baseline": counts(baseline["teeth"]), "after_cross_roi_assignment": counts(teeth),
              "cross_roi_candidates": reassignment, "uses_ground_truth": False, "training_steps": 0,
              "model_thresholds_unchanged": {"object": .25, "nms_iou": .5, "each_point": .30}}
    views = {}
    start = time.perf_counter()
    if not args.assignment_only:
        path = verified_model_path(args.models, POSE)
        for rotation in (0, 180):
            view = _pose(rgb, teeth, [mask.astype(np.uint8) for mask in masks], path, args.output,
                         lambda event: print(json.dumps(event, ensure_ascii=False), flush=True), None,
                         roi_margin=(1.25, .15), rotation=rotation, skip_complete=True,
                         raw_folder=f"raw_pose/extra_context_{rotation}")
            views[str(rotation)] = view
            report[f"after_extra_context_{rotation}"] = counts(teeth)
    report["boundary_constraint"] = project_teeth(teeth)
    report["extra_inference"] = views
    report["elapsed_extra_seconds"] = time.perf_counter() - start
    report["peak_worker_working_set_gib"] = _peak_working_set()
    report["accuracy"] = "not_evaluated_geometry_projection_is_not_anatomy_validation"
    _overlay(rgb, teeth, args.output)
    _json(args.output / "report.json", report)
    _json(args.output / "projected_teeth.json", {"teeth": teeth, "report": report})
    print(json.dumps(report, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
