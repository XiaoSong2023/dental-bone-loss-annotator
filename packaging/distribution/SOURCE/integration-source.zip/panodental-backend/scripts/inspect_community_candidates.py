"""Inspect verified candidates without executing third-party Python or full-model pickle."""
import argparse
import hashlib
import json
from pathlib import Path
import pickletools
import zipfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--models", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    manifest = json.loads((args.models / "manifest.local.json").read_text(encoding="utf-8"))
    reports = []
    for entry in manifest:
        path = args.models / entry["repo"].replace("/", "--") / entry["file"]
        with path.open("rb") as stream:
            if hashlib.file_digest(stream, "sha256").hexdigest() != entry["sha256"]:
                raise ValueError("Candidate checksum changed")
        report = {"repo": entry["repo"], "file": entry["file"], "sha256": entry["sha256"]}
        if path.suffix == ".onnx":
            import onnx
            model = onnx.load(path, load_external_data=False)
            if any(t.data_location == onnx.TensorProto.EXTERNAL for t in model.graph.initializer):
                raise ValueError("External tensors require separate review")
            onnx.checker.check_model(model)
            def info(t):
                return {"name": t.name, "element_type": t.type.tensor_type.elem_type,
                        "shape": [d.dim_value or d.dim_param for d in t.type.tensor_type.shape.dim]}
            report.update({"checker": "PASS", "inputs": [info(t) for t in model.graph.input],
                           "outputs": [info(t) for t in model.graph.output],
                           "opsets": {t.domain: t.version for t in model.opset_import},
                           "metadata": {p.key: p.value for p in model.metadata_props},
                           "external_data": False, "initializer_count": len(model.graph.initializer),
                           "node_count": len(model.graph.node), "inference": "NOT_RUN"})
            del model
        elif path.suffix == ".pth":
            import torch
            from torchvision.models.detection import MaskRCNN
            from torchvision.models.detection.backbone_utils import resnet_fpn_backbone
            state = torch.load(path, map_location="meta", weights_only=True)
            if not isinstance(state, dict) or not all(isinstance(v, torch.Tensor) for v in state.values()):
                raise ValueError("Expected tensor-only Mask R-CNN state_dict")
            with torch.device("meta"):
                backbone = resnet_fpn_backbone(backbone_name="resnet50", weights=None, trainable_layers=3)
                model = MaskRCNN(backbone, num_classes=53, box_nms_thresh=.5,
                                 box_score_thresh=.3, box_detections_per_img=60)
                model.load_state_dict(state, strict=True)
            report.update({"tensor_only_load": True, "allocation_device": "meta", "strict_state_dict": "PASS",
                           "tensor_count": len(state), "parameter_count": sum(p.numel() for p in model.parameters()),
                           "head_shapes": {k: list(v.shape) for k, v in state.items()
                                           if any(x in k for x in ("cls_score", "bbox_pred", "mask_fcn_logits"))},
                           "inference": "NOT_RUN", "architecture": "torchvision Mask R-CNN ResNet50 FPN, 53 classes"})
            del model, state
        else:
            with zipfile.ZipFile(path) as archive:
                name, = [n for n in archive.namelist() if n.endswith("/data.pkl")]
                ops = list(pickletools.genops(archive.read(name)))
            strings = [v for op, v, _ in ops if op.name in {"BINUNICODE", "SHORT_BINUNICODE", "UNICODE"}]
            globals_ = sorted({v for op, v, _ in ops if op.name == "GLOBAL"})
            report.update({"pickle_executed": False, "globals": globals_,
                           "relevant_strings": [s for s in strings if s.endswith((".yaml", ".pt"))
                                                or s in {"surface", "pose", "segment", "Ultralytics"}],
                           "inference": "NOT_RUN"})
        reports.append(report)
        print(json.dumps(report, ensure_ascii=False), flush=True)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(reports, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
