"""Read Windows capacity and count the specified keypoint model on the meta device.

This gate is conservative admission policy, not a measured training OOM or speed test.
No model is trained and no predictions or checkpoints are generated.
"""
import argparse
import ctypes
from datetime import datetime, timezone
import json
from pathlib import Path
import platform
import subprocess


def memory_status():
    class MemoryStatus(ctypes.Structure):
        _fields_ = [("length", ctypes.c_ulong), ("load", ctypes.c_ulong)] + [
            (name, ctypes.c_ulonglong) for name in
            ("total_physical", "available_physical", "total_pagefile", "available_pagefile",
             "total_virtual", "available_virtual", "available_extended")]
    state = MemoryStatus()
    state.length = ctypes.sizeof(state)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(state)):
        raise OSError("GlobalMemoryStatusEx failed")
    return {"memory_load_percent": state.load,
            "total_physical_gib": state.total_physical / 2**30,
            "available_physical_gib": state.available_physical / 2**30}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    if platform.system() != "Windows":
        raise RuntimeError("This preflight targets the observed Windows workstation")
    memory_before = memory_status()
    command = "Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion | ConvertTo-Json -Compress"
    gpu = json.loads(subprocess.check_output(["powershell", "-NoProfile", "-Command", command], text=True))
    import torch
    import torchvision
    from torchvision.models.detection import keypointrcnn_resnet50_fpn
    with torch.device("meta"):
        model = keypointrcnn_resnet50_fpn(weights=None, weights_backbone=None, num_classes=3, num_keypoints=2)
    count = sum(p.numel() for p in model.parameters())
    report = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(), "platform": platform.platform(),
        "memory_before_import": memory_before, "memory_after_import": memory_status(), "gpu": gpu,
        "python": platform.python_version(), "torch": torch.__version__, "torchvision": torchvision.__version__,
        "torch_cuda_build": torch.version.cuda, "cuda_available_in_installed_build": torch.cuda.is_available(),
        "model": "specified Keypoint R-CNN ResNet50 FPN, 3 classes, 2 slots", "parameter_count": count,
        "allocation_device": "meta", "fp32_parameters_gradients_adam_states_gib_lower_bound": count * 16 / 2**30,
        "activations_batches_runtime_included_in_lower_bound": False,
        "admission_policy": {"minimum_free_ram_gib": 6.0, "measured_model_minimum": False,
                             "reason": "Leave room for feature maps, proposals, backward, data loading and Windows"},
        "free_ram_gate_passed": memory_before["available_physical_gib"] >= 6.0,
        "observed_rx6800s_official_rocm_support": "NOT_LISTED_ON_CHECKED_MATRIX",
        "rocm_matrix_url": "https://rocm.docs.amd.com/en/latest/compatibility/compatibility-matrix.html",
        "directml": "UNTESTED; separate backend and dependency versions required, not proven training support",
        "cpu_training_theoretically_possible": True,
        "training_decision": ("NOT_STARTED_CURRENT_CAPACITY_NOT_ADMITTED"
                              if memory_before["available_physical_gib"] < 6.0
                              else "NOT_STARTED_FREE_RAM_GATE_PASSED_ACCELERATED_TRAINING_UNVERIFIED"),
        "training_steps_run": 0, "speed_estimate": None, "accuracy": "NOT_EVALUATED",
        "user_stop_condition": "Do not start sustained training when this workstation cannot sustain the workload",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
