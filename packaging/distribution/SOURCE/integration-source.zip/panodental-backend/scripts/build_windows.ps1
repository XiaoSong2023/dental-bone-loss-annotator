$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
if ($env:OS -ne 'Windows_NT') { throw 'This build requires native Windows.' }
$pythonPath = Join-Path $projectRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $pythonPath)) { throw 'Create the project environment first.' }
Push-Location -LiteralPath $projectRoot
try {
    & $pythonPath -m PyInstaller --noconfirm packaging/windows.spec
    if ($LASTEXITCODE -ne 0) { throw 'PyInstaller build failed.' }
    Write-Output (Join-Path $projectRoot 'dist\PanoDental\PanoDental.exe')
} finally { Pop-Location }
