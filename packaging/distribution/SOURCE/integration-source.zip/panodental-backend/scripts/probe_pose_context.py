"""Compare a recorded ROI profile using cached real automatic segmentation only."""
import argparse
import hashlib
import json
from pathlib import Path
import time

import numpy as np
from PIL import Image

from panodental.inference import POSE, _json, _overlay, _peak_working_set, _pose, verified_model_path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--segmentation-result", required=True, type=Path)
    parser.add_argument("--models", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--horizontal-margin", type=float, required=True)
    parser.add_argument("--retry-180", action="store_true")
    args = parser.parse_args()
    if not 0 <= args.horizontal_margin <= 2:
        raise ValueError("Context margin outside bounded experiment range")
    args.output.mkdir(parents=True, exist_ok=False)
    source = args.segmentation_result.parent
    raw = args.segmentation_result.read_bytes()
    result = json.loads(raw)
    if result.get("status") != "completed" or result["segmentation"]["native_detection_count"] <= 0:
        raise ValueError("Expected completed real model segmentation")
    if "context_experiment" in result:
        source = Path(result["context_experiment"]["cached_automatic_segmentation"]).parent
    rgb = np.asarray(Image.open(source / result["image"]["canonical_ref"]).convert("RGB"))
    teeth = result["teeth"]
    masks = [np.asarray(Image.open(source / t["mask_ref"]).convert("L")) > 0 for t in teeth]
    if not args.retry_180:
        for tooth in teeth:
            tooth["surfaces"] = []
    model = verified_model_path(args.models, POSE)
    start = time.perf_counter()
    result["keypoints"] = _pose(rgb, teeth, [m.astype(np.uint8) for m in masks], model,
                               args.output, lambda r: print(json.dumps(r), flush=True), None,
                               roi_margin=(args.horizontal_margin, .15),
                               rotation=180 if args.retry_180 else 0, skip_complete=args.retry_180)
    result["context_experiment"] = {"uses_ground_truth": False,
                                     "cached_automatic_segmentation": str((source / "result.json").resolve()),
                                     "previous_pose_result": str(args.segmentation_result.resolve()),
                                     "cached_result_sha256": hashlib.sha256(raw).hexdigest(),
                                     "horizontal_margin": args.horizontal_margin,
                                     "retry_180_only_for_missing": args.retry_180,
                                     "elapsed_seconds": time.perf_counter() - start}
    result["peak_worker_working_set_gib"] = _peak_working_set()
    _overlay(rgb, teeth, args.output)
    _json(args.output / "result.json", result)
    print(json.dumps(result["keypoints"]), flush=True)


if __name__ == "__main__":
    main()
