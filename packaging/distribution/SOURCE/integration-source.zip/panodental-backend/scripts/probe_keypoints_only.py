"""Real pose-only inference on saved segmentation geometry; no labels or training.

One existing detected ROI can deliberately omit its contour to exercise the
manual-box contract. That alteration is an engineering fixture, not expert truth.
"""
import argparse
import builtins
import copy
import hashlib
import json
from pathlib import Path
import sys
import time

from training_preflight import memory_status


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", type=Path, required=True)
    parser.add_argument("--seg-result", type=Path, required=True)
    parser.add_argument("--models", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--manual-roi-fdi", type=int, default=36)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    before = memory_status()
    if before["available_physical_gib"] < 1.0:
        raise RuntimeError("Less than 1 GiB available; pose probe not admitted")
    original_import = builtins.__import__
    forbidden_imports = []
    def guarded_import(name, *positional, **kwargs):
        if name.split(".")[0] in ("torch", "torchvision"):
            forbidden_imports.append(name)
            raise AssertionError("Pose-only run must not import Torch or Torchvision")
        return original_import(name, *positional, **kwargs)
    builtins.__import__ = guarded_import
    from panodental import inference
    source = json.loads(args.seg_result.read_text(encoding="utf-8"))
    assert source["image"]["sha256"] == hashlib.sha256(args.image.read_bytes()).hexdigest()
    rows, manual_id = [], None
    for index, tooth in enumerate(source["teeth"]):
        ident = f"existing-ui-id-{index:03}"
        row = {"source_tooth_id": ident, "instance_id": ident,
               "fdi": tooth["fdi"], "origin": "model", "score": tooth["score"],
               "bbox_xyxy": copy.deepcopy(tooth["bbox_xyxy"]), "contours": copy.deepcopy(tooth["contours"])}
        if tooth["fdi"] == args.manual_roi_fdi and manual_id is None:
            row.update(origin="manual", score=None, contours=[])
            manual_id = ident
        rows.append(row)
    assert manual_id is not None, "Requested existing ROI not found"
    document = {"schema_version": 1, "image": {key: source["image"][key] for key in ("width", "height", "sha256")},
                "teeth": rows}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    snapshot = args.output.with_suffix(".teeth.json")
    snapshot.write_text(json.dumps(document, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    checked_models, segment_calls = [], []
    original_verify = inference.verified_model_path
    def verified_models(root, spec):
        checked_models.append(spec["repo"])
        assert spec == inference.POSE, "Pose-only mode checked a segmentation model"
        return original_verify(root, spec)
    inference.verified_model_path = verified_models
    def forbidden_segment(*a, **kw):
        segment_calls.append(True)
        raise AssertionError("Pose-only mode invoked segmentation")
    inference._segment = forbidden_segment
    started = time.perf_counter()
    result = inference.analyze_image(args.image, args.models, args.output, mode="keypoints", teeth_path=snapshot,
                                     progress=lambda event: print(json.dumps(event, ensure_ascii=False), flush=True))
    wall = time.perf_counter() - started
    assert len(result["teeth"]) == len(rows)
    for row, tooth in zip(rows, result["teeth"]):
        assert {key: tooth[key] for key in row} == row
    assert result["segmentation"]["status"] == "not_requested"
    assert result["segmentation"]["forward_count"] == 0 and not segment_calls
    assert result["models"]["segmentation"] is None
    assert not (args.output / "raw_segmentation").exists() and not (args.output / "masks").exists()
    assert not forbidden_imports and not any(n.split(".")[0] in ("torch", "torchvision") for n in sys.modules)
    assert checked_models == [inference.POSE["repo"]]
    decoded = json.loads((args.output / result["keypoints"]["decoded_ref"]).read_text(encoding="utf-8"))
    raw_surfaces = {surface["surface_id"]: surface for record in decoded for surface in record["surfaces"]}
    per_tooth, raw_checks = [], 0
    for tooth in result["teeth"]:
        for surface in tooth["surfaces"]:
            raw = raw_surfaces[surface["surface_id"]]
            for kind, point in surface["points"].items():
                assert point["raw_xy"] == raw["points"][kind]["raw_xy"]
                assert point["score"] == raw["points"][kind]["score"]
                raw_checks += 1
                if not tooth["contours"]:
                    assert point["xy"] == raw["points"][kind]["xy"]
                    assert point["boundary_projection"] is None and point["projected_xy"] is None
        per_tooth.append({"source_tooth_id": tooth["source_tooth_id"], "fdi": tooth["fdi"],
                          "contour_present": bool(tooth["contours"]), "surface_count": len(tooth["surfaces"]),
                          "point_count": sum(len(s["points"]) for s in tooth["surfaces"])})
    assert result["boundary_constraint"]["maximum_boundary_residual_px"] < 1e-10
    report = {"status": "passed", "mode": "keypoints", "real_trained_model": True,
              "training_steps": 0, "ground_truth_used": False, "clinical_accuracy_evaluated": False,
              "manual_roi_scope": "Existing model-detected ROI with contour deliberately omitted to test contract; not human ground truth",
              "input_sha256": document["image"]["sha256"], "snapshot_sha256": result["teeth_source"]["sha256"],
              "same_tooth_count_order_ids_fdi_bbox_contours_origin_score": True,
              "teeth": len(rows), "manual_roi_id": manual_id, "per_tooth": per_tooth,
              "surface_count": result["keypoints"]["surface_count"],
              "teeth_with_surfaces": result["keypoints"]["teeth_with_surfaces"],
              "point_count_raw_and_score_verified": raw_checks,
              "boundary_constraint": result["boundary_constraint"],
              "segmentation_forward_count": 0, "torch_import_attempts": forbidden_imports,
              "torch_modules_loaded": False, "verified_models": checked_models,
              "wall_seconds": wall, "elapsed_seconds": result["elapsed_seconds"],
              "peak_worker_working_set_gib": result["peak_worker_working_set_gib"],
              "pose_forward_count": result["keypoints"]["forward_count"], "memory_before": before,
              "memory_after": memory_status()}
    report_path = args.output.with_suffix(".report.json")
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    print(json.dumps({"report": str(report_path), **{k: report[k] for k in
          ("status", "teeth", "surface_count", "teeth_with_surfaces", "wall_seconds", "peak_worker_working_set_gib")}}), flush=True)


if __name__ == "__main__":
    main()
