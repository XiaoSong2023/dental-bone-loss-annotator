# PanoDental

Windows 全景片标注工作台开发版：人工轮廓/三类点编辑、复核、保存重开和导出已实现，22 项工程测试通过。**自动模型尚未接入，没有安装包。**

已找到社区分割与三点候选权重并下载校验；三点模型完成真实裁剪 CPU 探针。当前资源未通过保守正式训练准入，未启动训练。原始购买源码保留。

- [当前状态](docs/STATUS.md)
- [接力命令](docs/HANDOFF.md)
- [社区权重及真实探针](docs/WEIGHT_SEARCH.md)
- [训练预检](docs/TRAINING_PREFLIGHT.md)
- [资产审计](docs/ASSET_AUDIT.md)

开发环境 Python3.11，在本目录 PowerShell 执行：

```powershell
uv sync --locked --extra dev --extra cpu --extra weight-audit
./.venv/Scripts/python.exe -m panodental gui
./.venv/Scripts/python.exe -m pytest -q
./.venv/Scripts/python.exe -m panodental doctor --json --cpu-check
```

doctor 因应用模型未配置退出2。手工和探针数据的来源均独立记录，不以人工点、真值框或随机模型冒充自动功能。三点探针三个裁剪中两个无保留候选，效果未经正式评价，根尖片发布指标不代表本软件精度。
