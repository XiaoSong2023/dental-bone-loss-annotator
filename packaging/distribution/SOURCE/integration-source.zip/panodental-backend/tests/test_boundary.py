"""Geometry and control-flow fixtures; these tests make no model-accuracy claim."""
import copy

import numpy as np
from PIL import Image
import pytest

from panodental.boundary import nearest_contour_point, project_surface, project_teeth
from panodental import inference


def test_projection_hits_segment_interior_and_closing_segment():
    triangle = [[[0., 0.], [10., 10.], [10., 0.]]]
    result = nearest_contour_point([4., 7.], triangle)
    np.testing.assert_allclose(result["projected_xy"], [5.5, 5.5], atol=1e-13)
    assert result["segment_index"] == 0
    assert result["segment_t"] == pytest.approx(.55)
    assert result["distance_px"] == pytest.approx(np.sqrt(4.5))
    result = nearest_contour_point([3., -4.], triangle)
    np.testing.assert_allclose(result["projected_xy"], [3., 0.])
    assert result["segment_index"] == 2
    assert result["distance_px"] == 4.


def test_projection_handles_separate_contours_zero_edges_and_invalid_data():
    contours = [[[0, 0], [0, 0], [10, 0]], [[30, 10], [40, 10], [40, 20], [30, 20]]]
    result = nearest_contour_point([34, 8], contours)
    assert result["contour_index"] == 1
    assert result["projected_xy"] == [34., 10.]
    assert nearest_contour_point([0, 0], contours)["distance_px"] == 0.
    with pytest.raises(ValueError, match="No valid"):
        nearest_contour_point([1, 2], [[]])
    with pytest.raises(ValueError, match="finite"):
        nearest_contour_point([np.nan, 2], contours)


def test_projection_preserves_model_raw_scores_and_does_not_invent_missing_points():
    original = {"surface_id": "math_fixture", "object_score": .88,
                "points": {"cej": {"xy": [4., 7.], "raw_xy": [4., 7.], "score": .75},
                           "bone_level": None}}
    before = copy.deepcopy(original)
    result = project_surface(original, [[[0., 0.], [10., 10.], [10., 0.]]])
    assert original == before
    assert result["points"]["cej"]["raw_xy"] == [4., 7.]
    assert result["points"]["cej"]["xy"] == [5.5, 5.5]
    assert result["points"]["cej"]["score"] == .75
    assert result["object_score"] == .88
    assert result["points"]["bone_level"] is None
    assert "apex" not in result["points"]


def test_projection_report_measures_actual_boundary_residual():
    teeth = [{"contours": [[[1., 2.], [21., 17.], [30., 1.]]],
              "surfaces": [{"points": {str(i): {"xy": xy, "score": .7}
                                          for i, xy in enumerate(([4., 12.], [30., 20.], [13., 3.]))}}]}]
    report = project_teeth(teeth)
    assert report["projected_point_count"] == 3
    assert report["maximum_boundary_residual_px"] < 1e-12
    assert report["maximum_projection_distance_px"] > 0
    assert report["anatomical_accuracy_claimed"] is False


def test_segmentation_mode_never_verifies_or_calls_pose(tmp_path, monkeypatch):
    image = tmp_path / "control_flow_fixture.png"
    Image.new("L", (16, 12)).save(image)
    verified = []
    monkeypatch.setattr(inference, "verified_model_path", lambda root, spec: verified.append(spec) or image)
    monkeypatch.setattr(inference, "_segment", lambda *args: ([], [], {"fixture_only": True}))
    def forbidden(*args, **kwargs):
        raise AssertionError("Segmentation-only mode touched the pose runtime")
    monkeypatch.setattr(inference, "_pose", forbidden)
    result = inference.analyze_image(image, tmp_path, tmp_path / "result", mode="segmentation")
    assert verified == [inference.SEGMENTATION]
    assert result["mode"] == "segmentation"
    assert result["models"]["keypoints"] is None
    assert result["keypoints"]["status"] == "not_requested"
    assert result["keypoints"]["forward_count"] == 0
    assert result["teeth"] == []
    assert not (tmp_path / "result/raw_pose").exists()


def _surface(ident, score, coords):
    return {"surface_id": ident, "object_score": score,
            "points": {kind: {"raw_xy": xy, "xy": xy, "score": .8}
                       for kind, xy in zip(inference.POINT_KINDS, coords)}}


def test_model_triplet_dedup_chooses_whole_prediction_and_preserves_other_side():
    tooth = {"bbox_xyxy": [0, 0, 100, 250], "surfaces": []}
    first = _surface("first", .7, [[10, 50], [12, 70], [45, 240]])
    higher = _surface("higher", .9, [[11, 51], [13, 71], [46, 239]])
    opposite = _surface("opposite", .8, [[90, 50], [88, 70], [45, 240]])
    inference.merge_surface_candidate(tooth, first)
    inference.merge_surface_candidate(tooth, higher)
    inference.merge_surface_candidate(tooth, opposite)
    assert [surface["surface_id"] for surface in tooth["surfaces"]] == ["higher", "opposite"]
    assert tooth["surfaces"][0]["points"] == higher["points"]
    assert first["points"]["cej"]["raw_xy"] == [10, 50]
    assert tooth["surface_selection"][0]["suppressed_surface_id"] == "first"
