"""Synthetic archive tests only; not dental-model validation."""

import io
import pickle
import unittest
import zipfile

from panodental.audit import checkpoint_metadata


class AuditSafetyTests(unittest.TestCase):
    def checkpoint(self, value):
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w") as archive:
            archive.writestr("model/data.pkl", pickle.dumps(value, protocol=2))
        return buffer.getvalue()

    def test_lfs_pointer_is_unusable(self):
        result = checkpoint_metadata(b"version https://git-lfs.github.com/spec/v1\noid sha256:123")
        self.assertFalse(result["usable"])
        self.assertEqual(result["format"], "git_lfs_pointer")

    def test_metadata_cannot_certify_a_dental_model(self):
        result = checkpoint_metadata(self.checkpoint({"nc": 52, "names": ["tooth-11"]}))
        self.assertFalse(result["usable"])
        self.assertEqual(result["dental_status"], "REQUIRES_MANUAL_AUDIT")

    def test_coco_is_rejected(self):
        result = checkpoint_metadata(self.checkpoint({"nc": 80, "names": ["person", "bicycle", "car", "toothbrush"], "data": "coco.yaml"}))
        self.assertEqual(result["dental_status"], "REJECTED_COCO")
        self.assertIn(80, result["nc_literal_evidence"])

    def test_pickle_global_is_inspected_without_execution(self):
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w") as archive:
            archive.writestr("model/data.pkl", b"cnot_a_real_module\nnot_a_real_callable\n.")
        result = checkpoint_metadata(buffer.getvalue())
        self.assertIn("not_a_real_module not_a_real_callable", result["globals"])
        self.assertFalse(result["deserialized"])


if __name__ == "__main__":
    unittest.main()
