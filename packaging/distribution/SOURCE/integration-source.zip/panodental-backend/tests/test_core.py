import csv
import json
import shutil

import numpy as np
from PIL import Image
import pytest
from pydantic import ValidationError

from panodental.domain import Annotation, Landmark, Tooth
from panodental.geometry import Transform, exif_transform, plan_roi
from panodental.imaging import read_image
from panodental.project import Document, atomic_json
from panodental.crops import export_crops


@pytest.mark.parametrize("orientation", range(1, 9))
def test_exif_mapping_matches_actual_image_pixels(tmp_path, orientation):
    pixels = np.arange(35, dtype=np.uint8).reshape(5, 7)
    im = Image.fromarray(pixels)
    exif = im.getexif()
    exif[274] = orientation
    path = tmp_path / "中文 方向.png"
    im.save(path, exif=exif)
    loaded = read_image(path)
    transform, size = exif_transform(orientation, 7, 5)
    assert loaded.pixels.size == size
    for y in range(5):
        for x in range(7):
            xx, yy = transform.apply([[x, y]])[0].astype(int)
            assert np.asarray(loaded.pixels)[yy, xx] == pixels[y, x]
    assert np.max(np.abs(transform.inverse().apply(transform.apply([[0, 0], [6, 4]])) - [[0, 0], [6, 4]])) < 1e-4


def test_crop_and_half_pixel_resize_roundtrip():
    t = Transform.crop_resize((100, 200, 301, 601), (333, 511), (7, 13))
    p = [[100, 200], [112.25, 230.5], [299.5, 598.25]]
    assert np.max(np.abs(t.inverse().apply(t.apply(p)) - p)) < 1e-4
    t = Transform.crop_resize((100, 200, 301, 601), (201, 401))
    assert t.inverse().apply([[12.25, 30.5]])[0] == pytest.approx([112.25, 230.5])
    roi = plan_roi((1, 2, 21, 42), (101, 63))
    assert roi == (0, 0, 26, 48)


def test_16_bit_is_preserved_and_multiframe_is_rejected(tmp_path):
    data = np.array([[0, 32000, 65535], [200, 400, 600]], dtype=np.uint16)
    path = tmp_path / "16位.tiff"
    Image.fromarray(data).save(path)
    loaded = read_image(path)
    assert loaded.record.bit_depth == 16
    assert np.array_equal(np.asarray(loaded.pixels), data)
    assert loaded.rgb8().size == (3, 2)
    Image.fromarray(data).save(path, save_all=True, append_images=[Image.fromarray(data)])
    with pytest.raises(ValueError, match="单帧"):
        read_image(path)


def test_landmark_null_nan_and_origin_contract():
    p = Landmark(instance_id="t", kind="cej", current_xy=(0, 0))
    assert p.current_xy == (0, 0)
    for values in ({"current_xy": None}, {"current_xy": (float("nan"), 0)},
                   {"current_xy": (1, 2), "origin": "model", "raw_xy": None}):
        with pytest.raises(ValidationError):
            Landmark(instance_id="t", kind="cej", **values)


def test_atomic_json_failure_does_not_damage_previous_file(tmp_path):
    path = tmp_path / "project.json"
    atomic_json(path, {"revision": 1})
    with pytest.raises(ValueError):
        atomic_json(path, {"revision": float("nan")})
    assert json.loads(path.read_text()) == {"revision": 1}


def test_edit_save_move_export_preserves_raw_and_missing(tmp_path):
    source = tmp_path / "输入.png"
    Image.new("L", (101, 63), 120).save(source)
    doc = Document.from_image(source)
    tooth_id = doc.add_tooth([(10, 10), (30, 10), (30, 50), (10, 50)])
    lm_id = doc.add_point(tooth_id, "cej", (12.25, 30.5))
    doc.move_point(lm_id, (13.75, 31.25))
    doc.set_point_status(lm_id, "not_visible")
    assert doc.annotation.landmarks[0].current_xy is None
    doc.undo()
    assert doc.annotation.landmarks[0].current_xy == (13.75, 31.25)
    doc.redo()
    doc.set_fdi(tooth_id, 11)
    doc.save(tmp_path / "原项目.panoproj")
    assert not doc.dirty
    copied = tmp_path / "搬移.panoproj"
    shutil.copytree(doc.root, copied)
    source.unlink()
    reopened = Document.open(copied)
    assert reopened.annotation.teeth[0].instance_id == tooth_id
    assert reopened.annotation.landmarks[0].location_status == "not_visible"
    assert reopened.annotation.landmarks[0].raw_xy is None
    folder = reopened.export(tmp_path / "导出")
    exported = Annotation.model_validate_json((folder / "annotations.json").read_text(encoding="utf8"))
    assert exported.revision == reopened.annotation.revision
    with (folder / "landmarks.csv").open(encoding="utf-8-sig", newline="") as stream:
        row = next(csv.DictReader(stream))
    assert row["current_x"] == "" and row["location_status"] == "not_visible"
    assert Image.open(folder / "overlay.png").size == (101, 63)
    assert Image.open(folder / "masks" / f"{tooth_id}.png").size == (101, 63)


def test_out_of_bounds_edits_and_path_traversal_are_rejected(tmp_path):
    source = tmp_path / "input.png"
    Image.new("RGB", (31, 21)).save(source)
    doc = Document.from_image(source)
    tid = doc.add_tooth([(1, 1), (20, 1), (20, 15)])
    with pytest.raises(ValueError):
        doc.add_point(tid, "apex", (31, 2))
    doc.save(tmp_path / "project.panoproj")
    pointer = json.loads((doc.root / "project.json").read_text())
    pointer["annotation_ref"] = "../outside.json"
    atomic_json(doc.root / "project.json", pointer)
    with pytest.raises(ValueError, match="路径"):
        Document.open(doc.root)


def test_tooth_crop_uses_unpainted_image_and_exact_origin(tmp_path):
    source = tmp_path / "crop.png"
    Image.new("RGB", (201, 101), (55, 66, 77)).save(source)
    doc = Document.from_image(source)
    tid = doc.add_tooth([(30, 20), (50, 20), (50, 70), (30, 70)])
    doc.add_point(tid, "cej", (40, 40))
    folder = export_crops(doc, tmp_path)
    record = json.loads((folder / "crops.json").read_text())["teeth"][0]
    crop = Image.open(folder / record["image_ref"])
    assert set(crop.getdata()) == {(55, 66, 77)}
    transform = Transform(np.array(record["crop_to_canonical"]))
    assert transform.apply([[0, 0]])[0] == pytest.approx(record["crop_xyxy"][:2])
