from pathlib import Path

from PIL import Image
import pytest
from PySide6.QtCore import QPointF, Qt
from PySide6.QtWidgets import QFileDialog

from panodental.project import Document
from panodental.ui.window import MainWindow


def test_canvas_draw_add_point_undo_save_reopen(qtbot, tmp_path, monkeypatch):
    image = tmp_path / "全景 测试.png"
    Image.new("RGB", (301, 151), (60, 60, 60)).save(image)
    window = MainWindow(start_worker=False)
    qtbot.addWidget(window)
    window.show()
    doc = window.add_image(image)
    qtbot.waitExposed(window)
    window.canvas.fit()
    window.mode.setCurrentIndex(window.mode.findData("draw"))
    for point in [(20, 20), (80, 20), (80, 120), (20, 120)]:
        qtbot.mouseClick(window.canvas.viewport(), Qt.MouseButton.LeftButton,
                         pos=window.canvas.mapFromScene(QPointF(*point)))
    qtbot.keyClick(window.canvas, Qt.Key.Key_Return)
    qtbot.waitUntil(lambda: len(doc.annotation.teeth) == 1)
    qtbot.waitUntil(lambda: window.selected_tooth is not None)
    window.mode.setCurrentIndex(window.mode.findData("add_cej"))
    window.canvas.scale(1.37, 1.37)
    target = (34.25, 51.5)
    qtbot.mouseClick(window.canvas.viewport(), Qt.MouseButton.LeftButton,
                     pos=window.canvas.mapFromScene(QPointF(*target)))
    qtbot.waitUntil(lambda: len(doc.annotation.landmarks) == 1)
    assert doc.annotation.landmarks[0].current_xy == pytest.approx(target, abs=1)
    doc.undo()
    assert not doc.annotation.landmarks
    doc.redo()
    project = tmp_path / "gui.panoproj"
    monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *a, **k: (str(project), ""))
    assert window._save()
    reopened = Document.open(project)
    assert reopened.annotation.landmarks[0].current_xy == doc.annotation.landmarks[0].current_xy
    assert not window.run_action.isEnabled()
    window.close()
