"""Snapshot/control-flow engineering fixtures, never dental model predictions."""
import builtins
import copy
import hashlib
import json

import numpy as np
from PIL import Image
import pytest

from panodental import inference
from panodental.boundary import project_teeth
from panodental.imaging import read_image
from panodental.tooth_snapshot import load_teeth_snapshot


def snapshot_fixture(tmp_path):
    image = tmp_path / "engineering.png"
    Image.new("L", (80, 100)).save(image)
    document = {"schema_version": 1, "image": {"width": 80, "height": 100,
                "sha256": hashlib.sha256(image.read_bytes()).hexdigest()}, "teeth": [
        {"source_tooth_id": "manual/id", "instance_id": "manual/id", "origin": "manual",
         "fdi": None, "score": None, "bbox_xyxy": [1.5, 5, 31.2, 95], "contours": []},
        {"source_tooth_id": "same-fdi-2", "instance_id": "same-fdi-2", "origin": "model",
         "fdi": 36, "score": .88, "bbox_xyxy": [40., 10., 70., 90.],
         "contours": [[[42., 12.], [68., 12.], [68., 88.], [42., 88.]]]},
    ]}
    path = tmp_path / "teeth.json"
    path.write_text(json.dumps(document), encoding="utf-8")
    return image, path, document


def test_snapshot_geometry_identity_and_private_rectangle_are_preserved(tmp_path):
    image, path, document = snapshot_fixture(tmp_path)
    teeth, regions, metadata, raw = load_teeth_snapshot(path, read_image(image).record)
    assert raw == path.read_bytes()
    assert metadata["sha256"] == hashlib.sha256(raw).hexdigest()
    for row, tooth in zip(document["teeth"], teeth):
        assert {key: tooth[key] for key in row} == row
    assert teeth[0]["contours"] == [] and teeth[0]["score"] is None
    assert regions[0][5, 1] == 1 and regions[0][94, 31] == 1
    assert regions[0][95, 1] == 0
    assert regions[1][12, 42] == 1 and regions[1][10, 40] == 0


@pytest.mark.parametrize("mutation", [
    lambda d: d["image"].update(sha256="0" * 64),
    lambda d: d["image"].update(width=79),
    lambda d: d.update(schema_version=True),
    lambda d: d.update(teeth=[]),
    lambda d: d["teeth"].append(copy.deepcopy(d["teeth"][0])),
    lambda d: d["teeth"][0].update(instance_id="different-id"),
    lambda d: d["teeth"][0].update(bbox_xyxy=[0, 0, 90, 90]),
    lambda d: d["teeth"][0].update(bbox_xyxy=[5, 5, 5, 90]),
    lambda d: d["teeth"][0].update(score=float("nan")),
    lambda d: d["teeth"][1].update(contours=[[[1, 1], [2, 2], [3, 3]]]),
    lambda d: d["teeth"][1].update(contours=[[[1, 1], [80, 2], [3, 3]]]),
    lambda d: d["teeth"][0].update(origin="invented"),
])
def test_invalid_snapshot_rejected_before_any_model_verification(tmp_path, monkeypatch, mutation):
    image, path, document = snapshot_fixture(tmp_path)
    mutation(document)
    path.write_text(json.dumps(document), encoding="utf-8")
    def forbidden(*args, **kwargs):
        pytest.fail("Invalid snapshot must fail before touching a model")
    monkeypatch.setattr(inference, "verified_model_path", forbidden)
    with pytest.raises(ValueError):
        inference.analyze_image(image, tmp_path, tmp_path / "output", mode="keypoints", teeth_path=path)
    assert not (tmp_path / "output").exists()


def test_keypoints_never_imports_torch_or_verifies_or_executes_segmentation(tmp_path, monkeypatch):
    image, path, document = snapshot_fixture(tmp_path)
    verified, progress = [], []
    monkeypatch.setattr(inference, "verified_model_path", lambda root, spec: verified.append(spec) or image)
    def forbidden(*args, **kwargs):
        pytest.fail("Keypoints-only mode touched segmentation")
    monkeypatch.setattr(inference, "_segment", forbidden)
    original_import = builtins.__import__
    def guarded_import(name, *args, **kwargs):
        if name.split(".")[0] in ("torch", "torchvision"):
            pytest.fail("Keypoints-only mode imported Torch")
        return original_import(name, *args, **kwargs)
    monkeypatch.setattr(builtins, "__import__", guarded_import)
    def empty_pose(rgb, teeth, masks, model, out, *args, raw_folder, **kwargs):
        # Explicit empty control-flow stub. Actual trained inference is separate.
        (out / raw_folder).mkdir(parents=True)
        (out / raw_folder / "decoded.json").write_text("[]")
        return {"forward_count": 0, "forward_seconds": 0., "surface_count": 0,
                "teeth_with_surfaces": 0, "decoded_ref": raw_folder + "/decoded.json"}
    monkeypatch.setattr(inference, "_pose", empty_pose)
    out = tmp_path / "out"
    result = inference.analyze_image(image, tmp_path, out, mode="keypoints", teeth_path=path,
                                     progress=progress.append)
    assert verified == [inference.POSE]
    assert result["models"]["segmentation"] is None
    assert result["segmentation"]["status"] == "not_requested"
    assert result["segmentation"]["forward_count"] == 0
    assert not any(event["stage"] == "segmentation" for event in progress)
    assert not (out / "raw_segmentation").exists() and not (out / "masks").exists()
    assert (out / "input_teeth.json").read_bytes() == path.read_bytes()
    for row, tooth in zip(document["teeth"], result["teeth"]):
        assert {key: tooth[key] for key in row} == row
        assert tooth["surfaces"] == []


def test_contourless_predictions_are_explicitly_unconstrained_not_projected_to_rectangle():
    point = {"xy": [15.3, 8.7], "raw_xy": [15.3, 8.7], "score": .7}
    teeth = [{"contours": [], "bbox_xyxy": [10, 10, 30, 50], "score": None,
              "surfaces": [{"points": {"cej": copy.deepcopy(point), "apex": None}}]},
             {"contours": [[[0, 0], [20, 0], [20, 20], [0, 20]]],
              "surfaces": [{"points": {"cej": copy.deepcopy(point)}}]}]
    report = project_teeth(teeth, reference="existing_snapshot_segmentation_contours")
    raw = teeth[0]["surfaces"][0]["points"]["cej"]
    assert {key: raw[key] for key in point} == point
    assert raw["projected_xy"] is None and raw["boundary_projection"] is None
    assert teeth[0]["contours"] == [] and teeth[0]["score"] is None
    assert teeth[0]["surfaces"][0]["postprocessing"] == "unconstrained_no_segmentation_contour"
    assert report["unconstrained_point_count"] == 1 and report["projected_point_count"] == 1
    assert report["maximum_boundary_residual_px"] < 1e-12


def test_teeth_argument_is_only_accepted_for_keypoints(tmp_path):
    for mode, teeth in (("keypoints", None), ("full", "anything"), ("segmentation", "anything")):
        with pytest.raises(ValueError, match="teeth"):
            inference.analyze_image("missing", "missing", tmp_path / "no-output", mode=mode, teeth_path=teeth)
