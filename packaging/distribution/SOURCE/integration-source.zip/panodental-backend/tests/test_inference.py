"""Coordinate/rejection contracts only; real-model verification is a separate probe."""
import hashlib

import cv2
import numpy as np
import pytest

from panodental.inference import (InferenceCancelled, analyze_image, decode_pose,
                                  letterbox_rgb, surface_to_tooth, verified_model_path)


def _output(points, score=.9):
    output = np.zeros((1, 14, 12096), dtype=np.float32)
    output[0, :, 0] = [384, 384, 300, 400, score, *np.array(points).reshape(-1)]
    return output


def test_odd_letterbox_restores_model_coordinate_convention():
    rgb = np.zeros((237, 101, 3), dtype=np.uint8)
    tensor, transform = letterbox_rgb(rgb)
    assert tensor.shape == (1, 3, 768, 768)
    assert tensor.flags.c_contiguous
    assert tensor.dtype == np.float32
    local = np.array([[0., 0.], [31.4, 121.6], [100., 236.]])
    network = local * transform["ratio"] + transform["padding_left_top"]
    predictions = _output(np.column_stack([network, [.8, .9, .95]]))
    surfaces = decode_pose(predictions, transform, (73, 48, 174, 285), (400, 400))
    assert len(surfaces) == 1
    assert surfaces[0]["accepted"]
    restored = np.array([p["xy"] for p in surfaces[0]["points"].values()])
    np.testing.assert_allclose(restored, local + [73, 48], atol=1e-4)
    assert surfaces[0]["points"]["cej"]["score"] == pytest.approx(.8)


def test_low_confidence_or_padding_points_are_retained_but_rejected():
    _, transform = letterbox_rgb(np.zeros((100, 200, 3), dtype=np.uint8))
    points = [[100, 250, .9], [200, 300, .29], [300, 350, .8]]
    surfaces = decode_pose(_output(points), transform, (0, 0, 200, 100), (200, 100))
    assert not surfaces[0]["accepted"]
    assert surfaces[0]["rejection_reason"] == "point_score_below_0.30"
    points[1][2] = .8
    points[0][1] = 10  # Inside letterbox padding, outside source crop.
    surfaces = decode_pose(_output(points), transform, (0, 0, 200, 100), (200, 100))
    assert not surfaces[0]["accepted"]
    assert surfaces[0]["rejection_reason"] == "point_outside_crop"
    assert surfaces[0]["points"]["cej"]["xy"][1] < 0  # Raw evidence is not clamped/fabricated.


def test_180_view_inverse_preserves_original_anatomical_slot_coordinates():
    _, transform = letterbox_rgb(np.zeros((237, 101, 3), dtype=np.uint8))
    transform["view_to_crop"] = [[-1, 0, 100], [0, -1, 236], [0, 0, 1]]
    original = np.array([[10., 20.], [30., 80.], [70., 190.]])
    view = [100, 236] - original
    network = view * transform["ratio"] + transform["padding_left_top"]
    surfaces = decode_pose(_output(np.column_stack([network, [.9, .8, .7]])), transform,
                           (71, 33, 172, 270), (400, 400))
    assert surfaces[0]["accepted"]
    for kind, expected in zip(("cej", "bone_level", "apex"), original + [71, 33]):
        np.testing.assert_allclose(surfaces[0]["points"][kind]["xy"], expected, atol=1e-4)


def test_no_detected_surface_returns_empty_and_nan_output_fails():
    _, transform = letterbox_rgb(np.zeros((100, 100, 3), dtype=np.uint8))
    output = np.zeros((1, 14, 12096), dtype=np.float32)
    assert decode_pose(output, transform, (0, 0, 100, 100), (100, 100)) == []
    output[0, 0, 0] = np.nan
    with pytest.raises(ValueError, match="non-finite"):
        decode_pose(output, transform, (0, 0, 100, 100), (100, 100))


def test_neighbour_tooth_association_and_ambiguous_overlap():
    masks = []
    for x in (10, 60):
        mask = np.zeros((100, 100), dtype=np.uint8)
        mask[10:90, x:x+20] = 1
        masks.append(mask)
    distances = [cv2.distanceTransform(1-mask, cv2.DIST_L2, 3) for mask in masks]
    teeth = [{"instance_id": "left", "bbox_xyxy": [10, 10, 30, 90]},
             {"instance_id": "right", "bbox_xyxy": [60, 10, 80, 90]}]
    surface = {"points": {"cej": {"xy": [70, 25]}, "apex": {"xy": [70, 85]}}}
    assigned, evidence = surface_to_tooth(surface, teeth, distances)
    assert assigned == "right"
    assert evidence["normalized_mean_distance"] == 0
    assigned, evidence = surface_to_tooth(surface, teeth, [distances[1], distances[1]])
    assert assigned is None
    assert evidence["reason"] == "ambiguous_tooth_association"


def test_checkpoint_checksum_and_failed_run_do_not_overwrite_assets(tmp_path):
    checkpoint = tmp_path / "publisher--model" / "weights.bin"
    checkpoint.parent.mkdir()
    checkpoint.write_bytes(b"fixed test file, never a model")
    spec = {"repo": "publisher/model", "filename": "weights.bin", "sha256": "0" * 64}
    with pytest.raises(ValueError, match="模型校验失败"):
        verified_model_path(tmp_path, spec)
    spec["sha256"] = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
    assert verified_model_path(tmp_path, spec) == checkpoint
    existing = tmp_path / "existing_run"
    existing.mkdir()
    sentinel = existing / "result.json"
    sentinel.write_text("do not replace")
    with pytest.raises(FileExistsError):
        analyze_image("missing", "missing", existing)
    assert sentinel.read_text() == "do not replace"
    cancelled_run = tmp_path / "cancelled"
    with pytest.raises(InferenceCancelled):
        analyze_image("missing", "missing", cancelled_run, cancelled=lambda: True)
    assert not cancelled_run.exists()
