import json
import os
from pathlib import Path
import subprocess
import sys

from panodental.runtime import health


def test_cpu_runtime_ops_without_trained_model():
    report = health()
    assert report["torch_cuda_build"] is None
    assert report["actual_device"] == "cpu"
    assert report["cpu_ops"] == "passed"
    assert report["trained_models"] == "missing"


def test_worker_protocol_error_is_not_a_success(tmp_path):
    messages = [
        {"request_id": "1", "command": "capabilities"},
        {"request_id": "2", "command": "run_image", "input": str(tmp_path / "missing.png")},
        {"request_id": "3", "command": "shutdown"},
    ]
    process = subprocess.run([sys.executable, "-m", "panodental.worker"],
                             input="".join(json.dumps(x)+"\n" for x in messages), text=True,
                             encoding="utf8", capture_output=True, timeout=60)
    assert process.returncode == 0, process.stderr
    responses = [json.loads(line) for line in process.stdout.splitlines()]
    error = next(row for row in responses if row["request_id"] == "2")
    assert error["type"] == "error"
    assert error["error_code"] == "MISSING_TRAINED_WEIGHTS"
    assert not list(tmp_path.iterdir())
